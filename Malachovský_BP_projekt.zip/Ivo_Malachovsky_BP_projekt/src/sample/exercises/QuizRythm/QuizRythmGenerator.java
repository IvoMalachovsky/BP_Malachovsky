package sample.exercises.QuizRythm;

import java.util.ArrayList;
import java.util.Random;

public class QuizRythmGenerator {
    private ArrayList<QuizRythmQuestion> noteLengths;
    private ArrayList<QuizRythmQuestion> tempNoteLengths;

    private String lastSelectedSymbol="";

    public QuizRythmGenerator(ArrayList<QuizRythmQuestion> noteLengths)
    {
        this.noteLengths = noteLengths;
    }

    public ArrayList<QuizRythmQuestion> generateQuestions(int numberOfQuestions) {
        tempNoteLengths = new ArrayList<QuizRythmQuestion>(noteLengths);

        ArrayList<QuizRythmQuestion> questions = new ArrayList<QuizRythmQuestion>();

        for (int i = 0; i<numberOfQuestions; i++)
        {
            questions.add(generateQuestion());
        }

        return questions;
    }

    public ArrayList<String> getNoteLengths() {

        ArrayList<String> noteLengthsArray = new ArrayList<String>();
        for(int i = 0; i<noteLengths.size();i++)
        {
            noteLengthsArray.add(noteLengths.get(i).getNoteLengthName());
        }

        return noteLengthsArray;
    }

    private QuizRythmQuestion generateQuestion() {
        Random rnd = new Random();
        QuizRythmQuestion question;

        if (tempNoteLengths.size() <= 0) {
            tempNoteLengths = new ArrayList<QuizRythmQuestion>(noteLengths);
        }
        int randomNoteLength = rnd.nextInt(tempNoteLengths.size());

        if(lastSelectedSymbol.equals(tempNoteLengths.get(randomNoteLength).getNoteLengthName()) && tempNoteLengths.size()>1)
        {
            tempNoteLengths.remove(randomNoteLength);
            randomNoteLength = rnd.nextInt(tempNoteLengths.size());
        }

        question = tempNoteLengths.get(randomNoteLength);
        lastSelectedSymbol = question.getNoteLengthName();
        tempNoteLengths.remove(randomNoteLength);

        return question;
    }
}
