package sample.exercises.QuizRythm;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.controllers.ControllerQuizRhythm;

import java.io.IOException;
import java.util.ArrayList;

public class QuizRythmExercise {
    //checkboxes
    public CheckBox answer1, answer2, answer3, answer4, answer5, answer6, answer7;

    public Button backToMenuButton;

    public TextField numberOfQuestionsField;

    private ArrayList<QuizRythmQuestion> answers = new ArrayList<QuizRythmQuestion>();

    private Parent root;
    private Scene scene;
    private Stage stage;

    private ArrayList<QuizRythmQuestion> noteLengths;


    public void startExcercise(MouseEvent mouseEvent) throws IOException {
        noteLengths = fillNoteLengths();

        boolean infinite = false;

        QuizRythmGenerator quizRythmGenerator = new QuizRythmGenerator(noteLengths);
        if(Integer.parseInt(numberOfQuestionsField.getText()) == 0) {
            answers = new ArrayList<QuizRythmQuestion>(quizRythmGenerator.generateQuestions(20));
            infinite = true;
        }
        else
        {
            answers = new ArrayList<QuizRythmQuestion>(quizRythmGenerator.generateQuestions(Integer.parseInt(numberOfQuestionsField.getText())));
        }


        FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/quizRhythm.fxml"));
        root = loader.load();


        ControllerQuizRhythm controllerQuizRhythm = loader.getController();
        controllerQuizRhythm.setAnswer(answers, 0,0,0, quizRythmGenerator, infinite);

        stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private ArrayList<QuizRythmQuestion> fillNoteLengths()
    {
        ArrayList<QuizRythmQuestion> tempNoteLengths = new ArrayList<QuizRythmQuestion>();

        if(answer1.isSelected())
        {
            tempNoteLengths.add(new QuizRythmQuestion("Celá", 1));
        }
        if(answer2.isSelected())
        {
            tempNoteLengths.add(new QuizRythmQuestion("Půlová",2));
        }
        if(answer3.isSelected())
        {
            tempNoteLengths.add(new QuizRythmQuestion("Čtvrťová",3));
        }
        if(answer4.isSelected())
        {
            tempNoteLengths.add(new QuizRythmQuestion("Osminová",4));
        }
        if(answer5.isSelected())
        {
            tempNoteLengths.add(new QuizRythmQuestion("Šestnáctinová",5));
        }
        if(answer6.isSelected())
        {
            tempNoteLengths.add(new QuizRythmQuestion("Dvaatřicetinová",6));
        }
        if(answer7.isSelected())
        {
            tempNoteLengths.add(new QuizRythmQuestion("Čtyřiašedesátinová",7));
        }


        return tempNoteLengths;
    }


    public void backToMenuButtonClick(MouseEvent mouseEvent) throws Exception{
        Parent parent = FXMLLoader.load(getClass().getResource("/sample/exerciseSelectionMenu.fxml"));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) backToMenuButton.getScene().getWindow();
        defaultScene.setScene(scene);
    }
}
