package sample.exercises.QuizRythm;

public class QuizRythmQuestion {
        private String noteLengthName;
        private int pictureId;

        public QuizRythmQuestion(String noteLengthName, int pictureId) {
            this.noteLengthName = noteLengthName;
            this.pictureId = pictureId;
        }

    public String getNoteLengthName() {
        return noteLengthName;
    }

    public int getPictureId() {
        return pictureId;
    }
}
