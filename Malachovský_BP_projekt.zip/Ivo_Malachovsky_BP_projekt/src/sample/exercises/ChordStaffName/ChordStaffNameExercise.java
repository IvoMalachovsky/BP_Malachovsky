package sample.exercises.ChordStaffName;

import javafx.collections.FXCollections;
import javafx.collections.ObservableSet;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.controllers.ControllerChordNameBar;

import java.io.IOException;
import java.util.ArrayList;

public class ChordStaffNameExercise {

    //checkboxes
    public CheckBox CRootSnk, DRootSnk, ERootSnk, FRootSnk, GRootSnk, ARootSnk, HRootSnk;
    public CheckBox CsRootSnk, DsRootSnk, EsRootSnk, FsRootSnk, GsRootSnk, AsRootSnk, HsRootSnk;
    public CheckBox CfRootSnk, DfRootSnk, EfRootSnk, FfRootSnk, GfRootSnk, AfRootSnk, HfRootSnk;

    public Label errorLabel;

    public CheckBox trebleKeySnk, bassKeySnk;
    public CheckBox major, minor, aug, dim, susTwo, susFour, seventhOne, seventhTwo, seventhThree, seventhFour, seventhFive, seventhSix, seventhSeven;
    public CheckBox octaveVarietySnk;
    public CheckBox inv0, inv1, inv2, inv3;

    public Button backToMenuButton;

    public TextField numberOfQuestionsField;

    private ArrayList<ChordStaffNameQuestion> answers = new ArrayList<ChordStaffNameQuestion>();

    private Parent root;
    private Scene scene;
    private Stage stage;

    private ArrayList<String> notes, types, keys;
    private ArrayList<Integer> octave, inversion;


    public void startExcercise(MouseEvent mouseEvent) throws IOException {
        notes = fillNotes();
        keys = fillKeys();
        types = fillTypes();
        octave = fillOctave();
        inversion = fillInversion();

        if(errorDetection()) {
            errorLabel.setText("Vyberte více inverzí!");
        }
        else{
            boolean infinite = false;

            ChordStaffNameGenerator chordStaffNameGenerator = new ChordStaffNameGenerator(notes, types, keys, octave, inversion);
            if (Integer.parseInt(numberOfQuestionsField.getText()) == 0) {
                answers = new ArrayList<ChordStaffNameQuestion>(chordStaffNameGenerator.generateQuestions(20));
                infinite = true;
            } else {
                answers = new ArrayList<ChordStaffNameQuestion>(chordStaffNameGenerator.generateQuestions(Integer.parseInt(numberOfQuestionsField.getText())));
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/chordNameBar.fxml"));
            root = loader.load();

            ControllerChordNameBar controllerChordNameBar = loader.getController();
            controllerChordNameBar.setAnswer(answers, 0, 0, 0, chordStaffNameGenerator, infinite);

            stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }

    public void initialize()
    {
       // inv3.setDisable(true);
    }

    private boolean errorDetection()
    {
        boolean error = false;

        if(inv3.isSelected() && inversion.size() == 1)
        {
            for(String type: types)
            {
                if(!type.contains("Septakord:"))
                {
                    error = true;
                }
            }
        }
        return error;
    }


    private ArrayList<String> fillNotes()
    {

        ArrayList<String> tempNotes = new ArrayList<String>();


        if(CRootSnk.isSelected())
        {
            tempNotes.add("C?");
        }
        if(DRootSnk.isSelected())
        {
            tempNotes.add("D?");
        }
        if(ERootSnk.isSelected())
        {
            tempNotes.add("E?");
        }
        if(FRootSnk.isSelected())
        {
            tempNotes.add("F?");
        }
        if(GRootSnk.isSelected())
        {
            tempNotes.add("G?");
        }
        if(ARootSnk.isSelected())
        {
            tempNotes.add("A?");
        }
        if(HRootSnk.isSelected())
        {
            tempNotes.add("H?");
        }
        if(CsRootSnk.isSelected())
        {
            tempNotes.add("C?s");
        }
        if(DsRootSnk.isSelected())
        {
            tempNotes.add("D?s");
        }
        if(EsRootSnk.isSelected())
        {
            tempNotes.add("E?s");
        }
        if(FsRootSnk.isSelected())
        {
            tempNotes.add("F?s");
        }
        if(GsRootSnk.isSelected())
        {
            tempNotes.add("G?s");
        }
        if(AsRootSnk.isSelected())
        {
            tempNotes.add("A?s");
        }
        if(HsRootSnk.isSelected())
        {
            tempNotes.add("H?s");
        }

        if(CfRootSnk.isSelected())
        {
            tempNotes.add("C?f");
        }
        if(DfRootSnk.isSelected())
        {
            tempNotes.add("D?f");
        }
        if(EfRootSnk.isSelected())
        {
            tempNotes.add("E?f");
        }
        if(FfRootSnk.isSelected())
        {
            tempNotes.add("F?f");
        }
        if(GfRootSnk.isSelected())
        {
            tempNotes.add("G?f");
        }
        if(AfRootSnk.isSelected())
        {
            tempNotes.add("A?f");
        }
        if(HfRootSnk.isSelected())
        {
            tempNotes.add("H?f");
        }

        return tempNotes;
    }

    private ArrayList<String> fillKeys()
    {
        ArrayList<String> tempKeys = new ArrayList<String>();

        if(trebleKeySnk.isSelected())
        {
            tempKeys.add("treble");
        }
        if(bassKeySnk.isSelected())
        {
            tempKeys.add("bass");
        }

        return tempKeys;
    }

    private ArrayList<Integer> fillOctave()
    {
        ArrayList<Integer> tempOctave = new ArrayList<Integer>();

        if(octaveVarietySnk.isSelected())
        {
            tempOctave.add(1);
            tempOctave.add(2);
        }
        else {
            tempOctave.add(1);
        }

        return tempOctave;
    }

    private ArrayList<String> fillTypes()
    {
        ArrayList<String> tempTypes = new ArrayList<String>();

        if(major.isSelected())
        {
            tempTypes.add("Dur");
        }
        if(minor.isSelected())
        {
            tempTypes.add("Moll");
        }
        if(aug.isSelected())
        {
            tempTypes.add("Zvětšený");
        }
        if(dim.isSelected())
        {
            tempTypes.add("Zmenšený");
        }
        if(susTwo.isSelected())
        {
            tempTypes.add("Sus2");
        }
        if(susFour.isSelected())
        {
            tempTypes.add("Sus4");
        }
        if(seventhOne.isSelected())
        {
            tempTypes.add("Septakord: Tvrdě velký");
        }
        if(seventhTwo.isSelected())
        {
            tempTypes.add("Septakord: Tvrdě malý");
        }
        if(seventhThree.isSelected())
        {
            tempTypes.add("Septakord: Měkce velký");
        }
        if(seventhFour.isSelected())
        {
            tempTypes.add("Septakord: Měkce malý");
        }
        if(seventhFive.isSelected())
        {
            tempTypes.add("Septakord: Zvětšeně velký");
        }
        if(seventhSix.isSelected())
        {
            tempTypes.add("Septakord: Zmenšeně malý");
        }
        if(seventhSeven.isSelected())
        {
            tempTypes.add("Septakord: Zmenšeně zmenšený");
        }

        return tempTypes;
    }

    private ArrayList<Integer> fillInversion()
    {
        ArrayList<Integer> tempInversion = new ArrayList<Integer>();

        if(inv0.isSelected())
        {
            tempInversion.add(0);
        }
        if(inv1.isSelected())
        {
            tempInversion.add(1);
        }
        if(inv2.isSelected())
        {
            tempInversion.add(2);
        }
        if(inv3.isSelected())
        {
            tempInversion.add(3);
        }

        return tempInversion;
    }

    public void backToMenuButtonClick(MouseEvent mouseEvent) throws Exception{
        Parent parent = FXMLLoader.load(getClass().getResource("/sample/exerciseSelectionMenu.fxml"));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) backToMenuButton.getScene().getWindow();
        defaultScene.setScene(scene);
    }

    public void inversionCheck(ActionEvent event) {
        if(seventhOne.isSelected() || seventhTwo.isSelected() || seventhThree.isSelected() || seventhFour.isSelected() || seventhFive.isSelected() || seventhSix.isSelected() || seventhSeven.isSelected())
        {
            inv3.setDisable(false);
        }
        else
        {
            inv3.setDisable(true);
            inv3.setSelected(false);
        }
    }
}
