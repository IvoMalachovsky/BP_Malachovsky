package sample.exercises.ChordStaffName;

public class ChordStaffNameQuestion {
    private String rootNote;
    private String chordType;
    private String key;
    private int inversion;

    public ChordStaffNameQuestion(String rootNote)
    {
        this.rootNote = rootNote;
    }

    public void setRootNote(String rootNote) {
        this.rootNote = rootNote;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getRootNote() {
        return rootNote;
    }

    public String getKey() {
        return key;
    }

    public String getChordType() {
        return chordType;
    }

    public void setChordType(String chordType) {
        this.chordType = chordType;
    }

    public int getInversion() {
        return inversion;
    }

    public void setInversion(int inversion) {
        this.inversion = inversion;
    }
}
