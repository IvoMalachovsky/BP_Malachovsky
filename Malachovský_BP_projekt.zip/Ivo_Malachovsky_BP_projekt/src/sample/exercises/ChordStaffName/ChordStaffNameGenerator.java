package sample.exercises.ChordStaffName;

import sample.exercises.ChordNameKey.ChordNameKeyQuestion;
import sample.exercises.QuizRythm.QuizRythmQuestion;
import sample.exercises.ScaleBarName.ScaleBarNameQuestion;
import sample.logic.AllNotes;
import sample.logic.GeneralGeneration;

import java.util.ArrayList;
import java.util.Random;

public class ChordStaffNameGenerator {
    private ArrayList<String> notes, types, keys;
    private ArrayList<Integer> octave, inversion;
    private ArrayList<String> tempNotes, tempTypes, tempKeys;
    private ArrayList<Integer> tempOctave, tempInversion;

    public ChordStaffNameGenerator(ArrayList<String> notes, ArrayList<String> types, ArrayList<String> keys, ArrayList<Integer> octave, ArrayList<Integer> inversion)
    {
        this.notes = new ArrayList<String>(notes);
        this.types = new ArrayList<String>(types);
        this.keys = new ArrayList<String>(keys);
        this.octave = new ArrayList<Integer>(octave);
        this.inversion = new ArrayList<Integer>(inversion);
    }

    public ArrayList<ChordStaffNameQuestion> generateQuestions(int numberOfQuestions) {
        tempNotes = new ArrayList<String>(notes);
        tempKeys = new ArrayList<String>(keys);
        tempTypes = new ArrayList<String>(types);
        tempOctave = new ArrayList<Integer>(octave);
        tempInversion = new ArrayList<Integer>(inversion);

        ArrayList<ChordStaffNameQuestion> questions = new ArrayList<ChordStaffNameQuestion>();

        for (int i = 0; i<numberOfQuestions; i++)
        {
            questions.add(generateQuestion());
        }

        return questions;
    }

    private ChordStaffNameQuestion generateQuestion() {
        Random rnd = new Random();
        ChordStaffNameQuestion question;
        GeneralGeneration gg = new GeneralGeneration();

        if (tempNotes.size() <= 0) {
            tempNotes = new ArrayList<String>(notes);
        }
        if (tempKeys.size() <= 0) {
            tempKeys = new ArrayList<String>(keys);
        }
        if (tempTypes.size() <= 0) {
            tempTypes = new ArrayList<String>(types);
        }
        if (tempOctave.size() <= 0) {
            tempOctave = new ArrayList<Integer>(octave);
        }
        if (tempInversion.size() <= 0) {
            tempInversion = new ArrayList<Integer>(inversion);
        }


        int randomTonic = rnd.nextInt(tempNotes.size());
        int randomKey = rnd.nextInt(tempKeys.size() * 2);
        int randomTypes = rnd.nextInt(tempTypes.size());
        int randomOctave = rnd.nextInt(tempOctave.size());
        int randomInversion = rnd.nextInt(tempInversion.size());

        question = new ChordStaffNameQuestion(gg.generateNote(tempNotes, randomTonic));
        question.setRootNote(gg.addGeneratedOctave(tempOctave, randomOctave, question.getRootNote()));

        question.setChordType(tempTypes.get(randomTypes));
        tempTypes.remove(randomTypes);

        if(tempInversion.get(randomInversion) == 3 && !question.getChordType().contains("Septakord"))
        {
            tempInversion = new ArrayList<Integer>(inversion);
            tempInversion.remove((Object) 3);
            randomInversion = rnd.nextInt(tempInversion.size());
        }

        question.setInversion(tempInversion.get(randomInversion));
        tempInversion.remove(randomInversion);


        question.setKey(gg.generateStaffKey(tempKeys, randomKey));

        return question;
    }

    public ArrayList<String> getNotes() {
        return notes;
    }

    public ArrayList<String> getTypes() {
        return types;
    }

    public ArrayList<Integer> getInversion() {
        return inversion;
    }
}
