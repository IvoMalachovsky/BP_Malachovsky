package sample.exercises.ScaleNameKey;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.controllers.ControllerScaleNameKey;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ScaleNameKeyExercise {
    //checkboxes
    public CheckBox CRootSnk, DRootSnk, ERootSnk, FRootSnk, GRootSnk, ARootSnk, HRootSnk;
    public CheckBox CsRootSnk, DsRootSnk, EsRootSnk, FsRootSnk, GsRootSnk, AsRootSnk, HsRootSnk;
    public CheckBox CfRootSnk, DfRootSnk, EfRootSnk, FfRootSnk, GfRootSnk, AfRootSnk, HfRootSnk;

    public CheckBox majorSnk, minorNSnk, minorHSnk, minorMSnk, wholeSnk, dorianSnk, phrygianSnk, lydianSnk, mixolydianSnk;

    public TextField numberOfQuestionsField;

    private ArrayList<ScaleNameKeyQuestion> answers = new ArrayList<ScaleNameKeyQuestion>();

    public Button backToMenuButton;

    private Parent root;
    private Scene scene;
    private Stage stage;

    private ArrayList<String> notes, types;
    private ArrayList<Integer> octave;


     public void startExcercise(MouseEvent mouseEvent) throws IOException {
         notes = fillNotes();
         types = fillTypes();
         octave = fillOctave();

         boolean infinite = false;

         ScaleNameKeyGenerator scaleNameKeyGenerator = new ScaleNameKeyGenerator(notes, types, octave);
         if(Integer.parseInt(numberOfQuestionsField.getText()) == 0) {
             answers = new ArrayList<ScaleNameKeyQuestion>(scaleNameKeyGenerator.generateQuestions(20));
             infinite = true;
         }
         else
         {
             answers = new ArrayList<ScaleNameKeyQuestion>(scaleNameKeyGenerator.generateQuestions(Integer.parseInt(numberOfQuestionsField.getText())));
         }

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/scaleNameKey.fxml"));
        root = loader.load();


        ControllerScaleNameKey controllerScaleNameKey = loader.getController();
        controllerScaleNameKey.setAnswer(answers, 0,0,0, scaleNameKeyGenerator, infinite);

        stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private ArrayList<String> fillNotes()
    {

        ArrayList<String> tempNotes = new ArrayList<String>();


        if(CRootSnk.isSelected())
        {
            tempNotes.add("C?");
        }
        if(DRootSnk.isSelected())
        {
            tempNotes.add("D?");
        }
        if(ERootSnk.isSelected())
        {
            tempNotes.add("E?");
        }
        if(FRootSnk.isSelected())
        {
            tempNotes.add("F?");
        }
        if(GRootSnk.isSelected())
        {
            tempNotes.add("G?");
        }
        if(ARootSnk.isSelected())
        {
            tempNotes.add("A?");
        }
        if(HRootSnk.isSelected())
        {
            tempNotes.add("H?");
        }

        if(CsRootSnk.isSelected())
        {
            tempNotes.add("C?s");
        }
        if(DsRootSnk.isSelected())
        {
            tempNotes.add("D?s");
        }
        if(EsRootSnk.isSelected())
        {
            tempNotes.add("E?s");
        }
        if(FsRootSnk.isSelected())
        {
            tempNotes.add("F?s");
        }
        if(GsRootSnk.isSelected())
        {
            tempNotes.add("G?s");
        }
        if(AsRootSnk.isSelected())
        {
            tempNotes.add("A?s");
        }
        if(HsRootSnk.isSelected())
        {
            tempNotes.add("H?s");
        }

        if(CfRootSnk.isSelected())
        {
            tempNotes.add("C?f");
        }
        if(DfRootSnk.isSelected())
        {
            tempNotes.add("D?f");
        }
        if(EfRootSnk.isSelected())
        {
            tempNotes.add("E?f");
        }
        if(FfRootSnk.isSelected())
        {
            tempNotes.add("F?f");
        }
        if(GfRootSnk.isSelected())
        {
            tempNotes.add("G?f");
        }
        if(AfRootSnk.isSelected())
        {
            tempNotes.add("A?f");
        }
        if(HfRootSnk.isSelected())
        {
            tempNotes.add("H?f");
        }

        return tempNotes;
    }

    private ArrayList<Integer> fillOctave()
    {
        ArrayList<Integer> tempOctave = new ArrayList<Integer>();

        tempOctave.add(1);

        return tempOctave;
    }

    private ArrayList<String> fillTypes()
    {
        ArrayList<String> tempTypes = new ArrayList<String>();

        if(majorSnk.isSelected())
        {
            tempTypes.add("Dur");
        }
        if(minorNSnk.isSelected())
        {
            tempTypes.add("Moll - přirozená");
        }
        if(minorHSnk.isSelected())
        {
            tempTypes.add("Moll - harmonická");
        }
        if(minorMSnk.isSelected())
        {
            tempTypes.add("Moll - melodická");
        }
        if(dorianSnk.isSelected())
        {
            tempTypes.add("Dórská");
        }
        if(phrygianSnk.isSelected())
        {
            tempTypes.add("Frygická");
        }
        if(lydianSnk.isSelected())
        {
            tempTypes.add("Lydická");
        }
        if(mixolydianSnk.isSelected())
        {
            tempTypes.add("Mixolydická");
        }
        if(wholeSnk.isSelected())
        {
            tempTypes.add("Celotónová");
        }


        return tempTypes;
    }

    public void backToMenuButtonClick(MouseEvent mouseEvent) throws Exception{
        Parent parent = FXMLLoader.load(getClass().getResource("/sample/exerciseSelectionMenu.fxml"));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) backToMenuButton.getScene().getWindow();
        defaultScene.setScene(scene);
    }

}
