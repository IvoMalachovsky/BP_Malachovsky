package sample.exercises.ScaleNameKey;

import sample.logic.AllNotes;
import sample.logic.GeneralGeneration;

import java.util.ArrayList;
import java.util.Random;

public class ScaleNameKeyGenerator {
    private ArrayList<String> notes,  types;
    private ArrayList<Integer> octave;
    private ArrayList<String> tempNotes,tempTypes;
    private ArrayList<Integer>  tempOctave;

    public ScaleNameKeyGenerator(ArrayList<String> notes, ArrayList<String> types, ArrayList<Integer> octave)
    {
        this.notes = new ArrayList<String>(notes);
        this.types = new ArrayList<String>(types);
        this.octave = new ArrayList<Integer>(octave);
    }

    public ArrayList<ScaleNameKeyQuestion> generateQuestions(int numberOfQuestions) {
        tempNotes = new ArrayList<String>(notes);
        tempTypes = new ArrayList<String>(types);
        tempOctave = new ArrayList<Integer>(octave);

        ArrayList<ScaleNameKeyQuestion> questions = new ArrayList<ScaleNameKeyQuestion>();

        for (int i = 0; i<numberOfQuestions; i++)
        {
            questions.add(generateQuestion());
        }

        return questions;
    }

    private ScaleNameKeyQuestion generateQuestion() {
        GeneralGeneration gg = new GeneralGeneration();
        Random rnd = new Random();
        ScaleNameKeyQuestion question;

        if (tempNotes.size() <= 0) {
            tempNotes = new ArrayList<String>(notes);
        }
        if (tempTypes.size() <= 0) {
            tempTypes = new ArrayList<String>(types);
        }
        if (tempOctave.size() <= 0) {
            tempOctave = new ArrayList<Integer>(octave);
        }

        int randomTonic = rnd.nextInt(tempNotes.size());
        int randomTypes = rnd.nextInt(tempTypes.size());
        int randomOctave = rnd.nextInt(tempOctave.size());

        question = new ScaleNameKeyQuestion(gg.generateNote(tempNotes, randomTonic));
        question.setRootNote(gg.addGeneratedOctave(tempOctave, randomOctave, question.getRootNote()));

        question.setScaleType(tempTypes.get(randomTypes));
        tempTypes.remove(randomTypes);

        question.setKey("treble");

        return question;
    }



}
