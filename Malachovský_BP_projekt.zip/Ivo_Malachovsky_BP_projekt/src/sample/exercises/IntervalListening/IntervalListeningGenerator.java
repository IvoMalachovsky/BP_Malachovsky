package sample.exercises.IntervalListening;

import sample.exercises.IntervalListening.IntervalListeningQuestion;
import sample.exercises.IntervalStaff.IntervalStaffQuestion;
import sample.logic.AllNotes;
import sample.logic.GeneralGeneration;

import java.util.ArrayList;
import java.util.Random;

public class IntervalListeningGenerator {
    private ArrayList<String> notes, directions;
    private ArrayList<Integer> names, octave;
    private ArrayList<Character> types;
    private ArrayList<String> tempNotes, tempDirections;
    private ArrayList<Integer> tempNames, tempOctave;
    private ArrayList<Character> tempTypes;

    public IntervalListeningGenerator (ArrayList<String> notes, ArrayList<Integer> names, ArrayList<Character> types, ArrayList<Integer> octave, ArrayList<String> directions)
    {
        this.notes = new ArrayList<String>(notes);
        this.names = new ArrayList<Integer>(names);
        this.types = new ArrayList<Character>(types);
        this.octave = new ArrayList<Integer>(octave);
        this.directions = new ArrayList<String>(directions);
    }

    public ArrayList<IntervalListeningQuestion> generateQuestions(int numberOfQuestions) {
        tempNotes = new ArrayList<String>(notes);
        tempNames = new ArrayList<Integer>(names);
        tempTypes = new ArrayList<Character>(types);
        tempOctave = new ArrayList<Integer>(octave);
        tempDirections = new ArrayList<String>(directions);

        ArrayList<IntervalListeningQuestion> questions = new ArrayList<IntervalListeningQuestion>();

        for (int i = 0; i<numberOfQuestions; i++)
        {
            questions.add(generateQuestion());
        }

        return questions;
    }

    private IntervalListeningQuestion generateQuestion() {
        Random rnd = new Random();
        IntervalListeningQuestion question;
        GeneralGeneration gg = new GeneralGeneration();

        if (tempNotes.size() <= 0) {
            tempNotes = new ArrayList<String>(notes);
        }
        if(tempNames.size() <= 0)
        {
            tempNames = new ArrayList<Integer>(names);
        }
        if (tempTypes.size() <= 0) {
            tempTypes = new ArrayList<Character>(types);
        }
        if (tempOctave.size() <= 0) {
            tempOctave = new ArrayList<Integer>(octave);
        }
        if(tempDirections.size() <= 0)
        {
            tempDirections = new ArrayList<String>(directions);
        }

        int randomTonic = rnd.nextInt(tempNotes.size());
        int randomType = rnd.nextInt(tempTypes.size());
        int randomOctave = rnd.nextInt(tempOctave.size());
        int randomName = rnd.nextInt(tempNames.size());
        int randomDirection = rnd.nextInt(tempDirections.size());

        question = new IntervalListeningQuestion(gg.generateNote(tempNotes, randomTonic));
        question.setRootNote(gg.addGeneratedOctave(tempOctave, randomOctave, question.getRootNote()));

        question.setIntervalName(tempNames.get(randomName));
        tempNames.remove(randomName);

        question.setIntervalType(tempTypes.get(randomType));
        tempTypes.remove(randomType);

        question.setAscending(gg.generateIntervalDirection(tempDirections, randomDirection));
        question.setKey("treble");

        return question;
    }

    public ArrayList<Integer> getIntervalNames() {
        return names;
    }

    public ArrayList<Character> getIntervalTypes() {
        return types;
    }
}
