package sample.exercises.ScaleBarName;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.controllers.ControllerScaleNameKey;
import sample.controllers.ControllerScalesBarName;
import sample.exercises.ScaleNameKey.ScaleNameKeyQuestion;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class ScaleBarNameExercise {
    //checkboxes
    public CheckBox CRootSnk, DRootSnk, ERootSnk, FRootSnk, GRootSnk, ARootSnk, HRootSnk;
    public CheckBox CsRootSnk, DsRootSnk, EsRootSnk, FsRootSnk, GsRootSnk, AsRootSnk, HsRootSnk;
    public CheckBox CfRootSnk, DfRootSnk, EfRootSnk, FfRootSnk, GfRootSnk, AfRootSnk, HfRootSnk;

    public CheckBox trebleKeySnk, bassKeySnk;
    public CheckBox majorSnk, minorNSnk, minorHSnk, minorMSnk, wholeSnk, dorianSnk, phrygianSnk, lydianSnk, mixolydianSnk;
    public CheckBox octaveVarietySnk;

    public Button backToMenuButton;

    public TextField numberOfQuestionsField;

    private ArrayList<ScaleBarNameQuestion> answers = new ArrayList<ScaleBarNameQuestion>();

    private Parent root;
    private Scene scene;
    private Stage stage;

    private ArrayList<String> notes, keys, types;
    private ArrayList<Integer> octave;


    public void startExcercise(MouseEvent mouseEvent) throws IOException {
        notes = fillNotes();
        keys = fillKeys();
        types = fillTypes();
        octave = fillOctave();

        boolean infinite = false;

        ScaleBarNameGenerator scaleBarNameGenerator = new ScaleBarNameGenerator(notes, types, keys, octave);
        if(Integer.parseInt(numberOfQuestionsField.getText()) == 0) {
            answers = new ArrayList<ScaleBarNameQuestion>(scaleBarNameGenerator.generateQuestions(20));
            infinite = true;
        }
        else
        {
            answers = new ArrayList<ScaleBarNameQuestion>(scaleBarNameGenerator.generateQuestions(Integer.parseInt(numberOfQuestionsField.getText())));
        }

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/scalesBarName.fxml"));
        root = loader.load();


        ControllerScalesBarName controllerScalesBarName = loader.getController();
        controllerScalesBarName.setAnswer(answers, 0,0,0, scaleBarNameGenerator, infinite);

        stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private ArrayList<String> fillNotes()
    {

        ArrayList<String> tempNotes = new ArrayList<String>();


        if(CRootSnk.isSelected())
        {
            tempNotes.add("C?");
        }
        if(DRootSnk.isSelected())
        {
            tempNotes.add("D?");
        }
        if(ERootSnk.isSelected())
        {
            tempNotes.add("E?");
        }
        if(FRootSnk.isSelected())
        {
            tempNotes.add("F?");
        }
        if(GRootSnk.isSelected())
        {
            tempNotes.add("G?");
        }
        if(ARootSnk.isSelected())
        {
            tempNotes.add("A?");
        }
        if(HRootSnk.isSelected())
        {
            tempNotes.add("H?");
        }
        if(CsRootSnk.isSelected())
        {
            tempNotes.add("C?s");
        }
        if(DsRootSnk.isSelected())
        {
            tempNotes.add("D?s");
        }
        if(EsRootSnk.isSelected())
        {
            tempNotes.add("E?s");
        }
        if(FsRootSnk.isSelected())
        {
            tempNotes.add("F?s");
        }
        if(GsRootSnk.isSelected())
        {
            tempNotes.add("G?s");
        }
        if(AsRootSnk.isSelected())
        {
            tempNotes.add("A?s");
        }
        if(HsRootSnk.isSelected())
        {
            tempNotes.add("H?s");
        }

        if(CfRootSnk.isSelected())
        {
            tempNotes.add("C?f");
        }
        if(DfRootSnk.isSelected())
        {
            tempNotes.add("D?f");
        }
        if(EfRootSnk.isSelected())
        {
            tempNotes.add("E?f");
        }
        if(FfRootSnk.isSelected())
        {
            tempNotes.add("F?f");
        }
        if(GfRootSnk.isSelected())
        {
            tempNotes.add("G?f");
        }
        if(AfRootSnk.isSelected())
        {
            tempNotes.add("A?f");
        }
        if(HfRootSnk.isSelected())
        {
            tempNotes.add("H?f");
        }

        return tempNotes;
    }

    private ArrayList<String> fillKeys()
    {
        ArrayList<String> tempKeys = new ArrayList<String>();

        if(trebleKeySnk.isSelected())
        {
            tempKeys.add("treble");
        }
        if(bassKeySnk.isSelected())
        {
            tempKeys.add("bass");
        }

        return tempKeys;
    }

    private ArrayList<Integer> fillOctave()
    {
        ArrayList<Integer> tempOctave = new ArrayList<Integer>();

        if(octaveVarietySnk.isSelected())
        {
            tempOctave.add(1);
            tempOctave.add(2);
        }
        else {
            tempOctave.add(1);
        }

        return tempOctave;
    }

    private ArrayList<String> fillTypes()
    {
        ArrayList<String> tempTypes = new ArrayList<String>();

        if(majorSnk.isSelected())
        {
            tempTypes.add("Dur");
        }
        if(minorNSnk.isSelected())
        {
            tempTypes.add("Moll - přirozená");
        }
        if(minorHSnk.isSelected())
        {
            tempTypes.add("Moll - harmonická");
        }
        if(minorMSnk.isSelected())
        {
            tempTypes.add("Moll - melodická");
        }
        if(dorianSnk.isSelected())
        {
            tempTypes.add("Dórská");
        }
        if(phrygianSnk.isSelected())
        {
            tempTypes.add("Frygická");
        }
        if(lydianSnk.isSelected())
        {
            tempTypes.add("Lydická");
        }
        if(mixolydianSnk.isSelected())
        {
            tempTypes.add("Mixolydická");
        }
        if(wholeSnk.isSelected())
        {
            tempTypes.add("Celotónová");
        }

        return tempTypes;
    }

    public void backToMenuButtonClick(MouseEvent mouseEvent) throws Exception{
        Parent parent = FXMLLoader.load(getClass().getResource("/sample/exerciseSelectionMenu.fxml"));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) backToMenuButton.getScene().getWindow();
        defaultScene.setScene(scene);
    }



}
