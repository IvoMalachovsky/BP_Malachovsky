package sample.exercises.ScaleBarName;

public class ScaleBarNameQuestion {
    private String rootNote;
    private String scaleType;
    private String key;

    public ScaleBarNameQuestion(String rootNote)
    {
        this.rootNote = rootNote;
    }

    public void setRootNote(String rootNote) {
        this.rootNote = rootNote;
    }

    public void setScaleType(String scaleType) {
        this.scaleType = scaleType;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getRootNote() {
        return rootNote;
    }

    public String getScaleType() {
        return scaleType;
    }

    public String getKey() {
        return key;
    }
}
