package sample.exercises.ChordNameKey;

public class ChordNameKeyQuestion {
    private String rootNote;
    private String chordType;
    private String key;
    private int inversion;

    public ChordNameKeyQuestion(String rootNote)
    {
        this.rootNote = rootNote;
    }

    public void setRootNote(String rootNote) {
        this.rootNote = rootNote;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getRootNote() {
        return rootNote;
    }

    public String getKey() {
        return key;
    }

    public String getChordType() {
        return chordType;
    }

    public void setChordType(String chordType) {
        this.chordType = chordType;
    }

    public int getInversion() {
        return inversion;
    }

    public void setInversion(int inversion) {
        this.inversion = inversion;
    }
}
