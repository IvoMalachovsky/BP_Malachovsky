package sample.exercises.NotesExercise;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.controllers.ControllerNotes;

import java.io.IOException;
import java.util.ArrayList;

public class NotesExercise {
    //checkboxes
    public CheckBox CRootSnk, DRootSnk, ERootSnk, FRootSnk, GRootSnk, ARootSnk, HRootSnk;
    public CheckBox CsRootSnk, DsRootSnk, EsRootSnk, FsRootSnk, GsRootSnk, AsRootSnk, HsRootSnk;
    public CheckBox CfRootSnk, DfRootSnk, EfRootSnk, FfRootSnk, GfRootSnk, AfRootSnk, HfRootSnk;

    public CheckBox trebleKeySnk, bassKeySnk;
    public CheckBox octaveVarietySnk;

    public TextField numberOfQuestionsField;

    private ArrayList<NotesQuestion> answers = new ArrayList<NotesQuestion>();

    public Button backToMenuButton;

    private Parent root;
    private Scene scene;
    private Stage stage;

    private ArrayList<String> notes, keys;
    private ArrayList<Integer> octave;


    public void startExcercise(MouseEvent mouseEvent) throws IOException {
        notes = fillNotes();
        keys = fillKeys();
        octave = fillOctave();

        boolean infinite = false;

        NotesGenerator notesGenerator = new NotesGenerator(notes, keys, octave);
        if(Integer.parseInt(numberOfQuestionsField.getText()) == 0) {
            answers = new ArrayList<NotesQuestion>(notesGenerator.generateQuestions(20));
            infinite = true;
        }
        else
        {
            answers = new ArrayList<NotesQuestion>(notesGenerator.generateQuestions(Integer.parseInt(numberOfQuestionsField.getText())));
        }

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/notes.fxml"));
        root = loader.load();


        ControllerNotes controllerNotes = loader.getController();
        controllerNotes.setAnswer(answers, 0,0,0, notesGenerator, infinite);

        stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private ArrayList<String> fillNotes()
    {

        ArrayList<String> tempNotes = new ArrayList<String>();


        if(CRootSnk.isSelected())
        {
            tempNotes.add("C?");
        }
        if(DRootSnk.isSelected())
        {
            tempNotes.add("D?");
        }
        if(ERootSnk.isSelected())
        {
            tempNotes.add("E?");
        }
        if(FRootSnk.isSelected())
        {
            tempNotes.add("F?");
        }
        if(GRootSnk.isSelected())
        {
            tempNotes.add("G?");
        }
        if(ARootSnk.isSelected())
        {
            tempNotes.add("A?");
        }
        if(HRootSnk.isSelected())
        {
            tempNotes.add("H?");
        }

        if(CsRootSnk.isSelected())
        {
            tempNotes.add("C?s");
        }
        if(DsRootSnk.isSelected())
        {
            tempNotes.add("D?s");
        }
        if(EsRootSnk.isSelected())
        {
            tempNotes.add("E?s");
        }
        if(FsRootSnk.isSelected())
        {
            tempNotes.add("F?s");
        }
        if(GsRootSnk.isSelected())
        {
            tempNotes.add("G?s");
        }
        if(AsRootSnk.isSelected())
        {
            tempNotes.add("A?s");
        }
        if(HsRootSnk.isSelected())
        {
            tempNotes.add("H?s");
        }

        if(CfRootSnk.isSelected())
        {
            tempNotes.add("C?f");
        }
        if(DfRootSnk.isSelected())
        {
            tempNotes.add("D?f");
        }
        if(EfRootSnk.isSelected())
        {
            tempNotes.add("E?f");
        }
        if(FfRootSnk.isSelected())
        {
            tempNotes.add("F?f");
        }
        if(GfRootSnk.isSelected())
        {
            tempNotes.add("G?f");
        }
        if(AfRootSnk.isSelected())
        {
            tempNotes.add("A?f");
        }
        if(HfRootSnk.isSelected())
        {
            tempNotes.add("H?f");
        }

        return tempNotes;
    }

    private ArrayList<String> fillKeys()
    {
        ArrayList<String> tempKeys = new ArrayList<String>();

        if(trebleKeySnk.isSelected())
        {
            tempKeys.add("treble");
        }
        if(bassKeySnk.isSelected())
        {
            tempKeys.add("bass");
        }

        return tempKeys;
    }

    private ArrayList<Integer> fillOctave()
    {
        ArrayList<Integer> tempOctave = new ArrayList<Integer>();

        if(octaveVarietySnk.isSelected())
        {
            tempOctave.add(1);
            tempOctave.add(2);
        }
        else {
            tempOctave.add(1);
        }

        return tempOctave;
    }

    public void backToMenuButtonClick(MouseEvent mouseEvent) throws Exception{
        Parent parent = FXMLLoader.load(getClass().getResource("/sample/exerciseSelectionMenu.fxml"));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) backToMenuButton.getScene().getWindow();
        defaultScene.setScene(scene);
    }



}
