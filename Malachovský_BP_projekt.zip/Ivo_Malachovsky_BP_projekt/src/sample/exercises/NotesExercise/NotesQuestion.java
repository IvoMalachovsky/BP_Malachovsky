package sample.exercises.NotesExercise;

public class NotesQuestion {
    private String Note;
    private String key;

    public NotesQuestion(String note) {
        Note = note;
    }

    public String getNote() {
        return Note;
    }

    public void setNote(String note) {
        Note = note;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
