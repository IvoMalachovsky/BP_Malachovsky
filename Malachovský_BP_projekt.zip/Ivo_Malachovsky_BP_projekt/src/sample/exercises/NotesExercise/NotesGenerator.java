package sample.exercises.NotesExercise;

import sample.exercises.ScaleNameKey.ScaleNameKeyQuestion;
import sample.logic.AllNotes;
import sample.logic.GeneralGeneration;

import java.util.ArrayList;
import java.util.Random;

public class NotesGenerator {

    private ArrayList<String> notes, keys;
    private ArrayList<Integer> octave;
    private ArrayList<String> tempNotes, tempKeys;
    private ArrayList<Integer> tempOctave;

    public NotesGenerator(ArrayList<String> notes, ArrayList<String> keys, ArrayList<Integer> octave)
    {
        this.notes = new ArrayList<String>(notes);
        this.keys = new ArrayList<String>(keys);
        this.octave = new ArrayList<Integer>(octave);
    }

    public ArrayList<NotesQuestion> generateQuestions(int numberOfQuestions) {
        tempNotes = new ArrayList<String>(notes);
        tempKeys = new ArrayList<String>(keys);
        tempOctave = new ArrayList<Integer>(octave);

        ArrayList<NotesQuestion> questions = new ArrayList<NotesQuestion>();

        for (int i = 0; i<numberOfQuestions; i++)
        {
            questions.add(generateQuestion());
        }

        return questions;
    }

    private NotesQuestion generateQuestion() {
        Random rnd = new Random();
        NotesQuestion question;
        GeneralGeneration gg = new GeneralGeneration();

        if (tempNotes.size() <= 0) {
            tempNotes = new ArrayList<String>(notes);
        }
        if (tempKeys.size() <= 0) {
            tempKeys = new ArrayList<String>(keys);
        }
        if (tempOctave.size() <= 0) {
            tempOctave = new ArrayList<Integer>(octave);
        }

        int randomTonic = rnd.nextInt(tempNotes.size());
        int randomKey = rnd.nextInt(tempKeys.size() * 2);
        int randomOctave = rnd.nextInt(tempOctave.size()*2);

        question = new NotesQuestion(gg.generateNote(tempNotes, randomTonic));
        question.setNote(gg.addGeneratedOctave(tempOctave, randomOctave, question.getNote()));
        question.setKey(gg.generateStaffKey(tempKeys, randomKey));

        return question;
    }



}
