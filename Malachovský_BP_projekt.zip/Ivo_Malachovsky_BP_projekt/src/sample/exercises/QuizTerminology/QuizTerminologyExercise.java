package sample.exercises.QuizTerminology;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.controllers.ControllerQuizTerminology;
import sample.elements.AllQuestions;
import sample.elements.QuestionQuiz;
import sample.elements.QuizQuestionGenerator;


import java.io.IOException;
import java.util.ArrayList;

public class QuizTerminologyExercise {
    //checkboxes
    public CheckBox answer1, answer2, answer3, answer4, answer5, answer6, answer7, answer8, answer9, answer10, answer11, answer12, answer13, answer14, answer15, answer16, answer17, answer18;
    public CheckBox answer19, answer20, answer21, answer22, answer23, answer24, answer25, answer26, answer27, answer28, answer29, answer30, answer31, answer32, answer33, answer34, answer35;
    public CheckBox answer36, answer37, answer38, answer39, answer40, answer41, answer42;

    private AllQuestions allQuestions = new AllQuestions();

    public Button backToMenuButton;

    public TextField numberOfQuestionsField;

    private ArrayList<QuestionQuiz> answers = new ArrayList<QuestionQuiz>();

    private Parent root;
    private Scene scene;
    private Stage stage;

    private ArrayList<QuestionQuiz> terms;


    public void startExcercise(MouseEvent mouseEvent) throws IOException {
        terms = fillTerms();

        boolean infinite = false;

        QuizQuestionGenerator generator = new QuizQuestionGenerator(terms);
        if(Integer.parseInt(numberOfQuestionsField.getText()) == 0) {
            answers = new ArrayList<QuestionQuiz>(generator.generateQuestions(20));
            infinite = true;
        }
        else
        {
            answers = new ArrayList<QuestionQuiz>(generator.generateQuestions(Integer.parseInt(numberOfQuestionsField.getText())));
        }

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/quizTerminology.fxml"));
        root = loader.load();


        ControllerQuizTerminology controllerQuizTerminology = loader.getController();
        controllerQuizTerminology.setAnswer(answers, 0,0,0, generator, infinite);

        stage = (Stage)((Node)mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private ArrayList<QuestionQuiz> fillTerms()
    {
        ArrayList<QuestionQuiz> tempQuestions = new ArrayList<QuestionQuiz>();

        if(answer1.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(0));
        }
        if(answer2.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(1));
        }
        if(answer3.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(2));
        }
        if(answer4.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(3));
        }
        if(answer5.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(4));
        }
        if(answer6.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(5));
        }
        if(answer7.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(6));
        }
        if(answer8.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(7));
        }
        if(answer9.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(8));
        }
        if(answer10.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(9));
        }
        if(answer11.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(10));
        }
        if(answer12.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(11));
        }
        if(answer13.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(12));
        }
        if(answer14.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(13));
        }
        if(answer15.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(14));
        }
        if(answer16.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(15));
        }
        if(answer17.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(16));
        }
        if(answer18.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(17));
        }
        if(answer19.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(18));
        }
        if(answer20.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(19));
        }
        if(answer21.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(20));
        }
        if(answer22.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(21));
        }
        if(answer23.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(22));
        }
        if(answer24.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(23));
        }
        if(answer25.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(24));
        }
        if(answer26.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(25));
        }
        if(answer27.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(26));
        }
        if(answer28.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(27));
        }
        if(answer29.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(28));
        }
        if(answer30.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(29));
        }
        if(answer31.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(30));
        }
        if(answer32.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(31));
        }
        if(answer33.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(32));
        }
        if(answer34.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(33));
        }
        if(answer35.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(34));
        }
        if(answer36.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(35));
        }
        if(answer37.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(36));
        }
        if(answer38.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(37));
        }
        if(answer39.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(38));
        }
        if(answer40.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(39));
        }
        if(answer41.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(40));
        }
        if(answer42.isSelected())
        {
            tempQuestions.add(allQuestions.getQuestionsList().get(41));
        }

        return tempQuestions;
    }


    public void backToMenuButtonClick(MouseEvent mouseEvent) throws Exception{
        Parent parent = FXMLLoader.load(getClass().getResource("/sample/exerciseSelectionMenu.fxml"));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) backToMenuButton.getScene().getWindow();
        defaultScene.setScene(scene);
    }
}
