package sample.exercises.IntervalStaff;

public class IntervalStaffQuestion {
    private String rootNote;
    private int intervalName;
    private char intervalType;
    private boolean ascending;
    private String key;

    public IntervalStaffQuestion(String rootNote)
    {
        this.rootNote = rootNote;
    }

    public String getRootNote() {
        return rootNote;
    }

    public void setRootNote(String rootNote) {
        this.rootNote = rootNote;
    }

    public int getIntervalName() {
        return intervalName;
    }

    public void setIntervalName(int intervalName) {
        this.intervalName = intervalName;
    }

    public char getIntervalType() {
        return intervalType;
    }

    public void setIntervalType(char intervalType) {
        this.intervalType = intervalType;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public boolean isAscending() {
        return ascending;
    }

    public void setAscending(boolean ascending) {
        this.ascending = ascending;
    }
}
