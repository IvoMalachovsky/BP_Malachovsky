package sample.exercises.IntervalStaff;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import sample.controllers.ControllerIntervalStaff;

import java.io.IOException;
import java.util.ArrayList;

public class IntervalStaffExercise {
    //checkboxes
    public CheckBox CRootSnk, DRootSnk, ERootSnk, FRootSnk, GRootSnk, ARootSnk, HRootSnk;
    public CheckBox CsRootSnk, DsRootSnk, EsRootSnk, FsRootSnk, GsRootSnk, AsRootSnk, HsRootSnk;
    public CheckBox CfRootSnk, DfRootSnk, EfRootSnk, FfRootSnk, GfRootSnk, AfRootSnk, HfRootSnk;

    public Label errorLabel;

    public CheckBox trebleKeySnk, bassKeySnk;
    public CheckBox namePrima, nameSekunda, nameTercie, nameKvarta, nameKvinta, nameSexta, nameSeptima, nameOktava;
    public CheckBox octaveVarietySnk;
    public CheckBox vType, mType, aType, dType;
    public CheckBox ascCheck, dcsCheck;

    public Button backToMenuButton;

    public TextField numberOfQuestionsField;

    private ArrayList<IntervalStaffQuestion> answers = new ArrayList<IntervalStaffQuestion>();

    private Parent root;
    private Scene scene;
    private Stage stage;

    private ArrayList<String> notes, keys, directions;
    private ArrayList<Integer> names, octave;
    private ArrayList<Character> types;


    public void startExcercise(MouseEvent mouseEvent) throws IOException {
        notes = fillNotes();
        keys = fillKeys();
        types = fillTypes();
        names = fillNames();
        octave = fillOctave();
        directions = fillDirection();


            boolean infinite = false;

            IntervalStaffGenerator intervalStaffGenerator = new IntervalStaffGenerator(notes, names, types, keys, octave, directions);
            if (Integer.parseInt(numberOfQuestionsField.getText()) == 0) {
                answers = new ArrayList<IntervalStaffQuestion>(intervalStaffGenerator.generateQuestions(20));
                infinite = true;
            } else {
                answers = new ArrayList<IntervalStaffQuestion>(intervalStaffGenerator.generateQuestions(Integer.parseInt(numberOfQuestionsField.getText())));
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/intervalStaff.fxml"));
            root = loader.load();


            ControllerIntervalStaff controllerIntervalStaff = loader.getController();
            controllerIntervalStaff.setAnswer(answers, 0, 0, 0, intervalStaffGenerator, infinite);

            stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

    }

    private ArrayList<String> fillNotes()
    {

        ArrayList<String> tempNotes = new ArrayList<String>();


        if(CRootSnk.isSelected())
        {
            tempNotes.add("C?");
        }
        if(DRootSnk.isSelected())
        {
            tempNotes.add("D?");
        }
        if(ERootSnk.isSelected())
        {
            tempNotes.add("E?");
        }
        if(FRootSnk.isSelected())
        {
            tempNotes.add("F?");
        }
        if(GRootSnk.isSelected())
        {
            tempNotes.add("G?");
        }
        if(ARootSnk.isSelected())
        {
            tempNotes.add("A?");
        }
        if(HRootSnk.isSelected())
        {
            tempNotes.add("H?");
        }

        if(CsRootSnk.isSelected())
        {
            tempNotes.add("C?s");
        }
        if(DsRootSnk.isSelected())
        {
            tempNotes.add("D?s");
        }
        if(EsRootSnk.isSelected())
        {
            tempNotes.add("E?s");
        }
        if(FsRootSnk.isSelected())
        {
            tempNotes.add("F?s");
        }
        if(GsRootSnk.isSelected())
        {
            tempNotes.add("G?s");
        }
        if(AsRootSnk.isSelected())
        {
            tempNotes.add("A?s");
        }
        if(HsRootSnk.isSelected())
        {
            tempNotes.add("H?s");
        }

        if(CfRootSnk.isSelected())
        {
            tempNotes.add("C?f");
        }
        if(DfRootSnk.isSelected())
        {
            tempNotes.add("D?f");
        }
        if(EfRootSnk.isSelected())
        {
            tempNotes.add("E?f");
        }
        if(FfRootSnk.isSelected())
        {
            tempNotes.add("F?f");
        }
        if(GfRootSnk.isSelected())
        {
            tempNotes.add("G?f");
        }
        if(AfRootSnk.isSelected())
        {
            tempNotes.add("A?f");
        }
        if(HfRootSnk.isSelected())
        {
            tempNotes.add("H?f");
        }

        return tempNotes;
    }

    private ArrayList<String> fillKeys()
    {
        ArrayList<String> tempKeys = new ArrayList<String>();

        if(trebleKeySnk.isSelected())
        {
            tempKeys.add("treble");
        }
        if(bassKeySnk.isSelected())
        {
            tempKeys.add("bass");
        }

        return tempKeys;
    }

    private ArrayList<String> fillDirection()
    {
        ArrayList<String> tempDirections = new ArrayList<String>();

        if(ascCheck.isSelected())
        {
            tempDirections.add("asc");
        }
        if(dcsCheck.isSelected())
        {
            tempDirections.add("dcs");
        }

        return tempDirections;
    }

    private ArrayList<Integer> fillOctave()
    {
        ArrayList<Integer> tempOctave = new ArrayList<Integer>();

        if(octaveVarietySnk.isSelected())
        {
            tempOctave.add(1);
            tempOctave.add(2);
        }
        else {
            tempOctave.add(1);
        }

        return tempOctave;
    }

    private ArrayList<Integer> fillNames()
    {
        ArrayList<Integer> tempNames = new ArrayList<Integer>();

        if(namePrima.isSelected())
        {
            tempNames.add(0);
        }
        if(nameSekunda.isSelected())
        {
            tempNames.add(1);
        }
        if(nameTercie.isSelected())
        {
            tempNames.add(2);
        }
        if(nameKvarta.isSelected())
        {
            tempNames.add(3);
        }
        if(nameKvinta.isSelected())
        {
            tempNames.add(4);
        }
        if(nameSexta.isSelected())
        {
            tempNames.add(5);
        }
        if(nameSeptima.isSelected())
        {
            tempNames.add(6);
        }
        if(nameOktava.isSelected())
        {
            tempNames.add(7);
        }

        return tempNames;
    }

    private ArrayList<Character> fillTypes()
    {
        ArrayList<Character> tempTypes = new ArrayList<Character>();

        if(vType.isSelected())
        {
            tempTypes.add('v');
        }
        if(mType.isSelected())
        {
            tempTypes.add('m');
        }
        if(aType.isSelected())
        {
            tempTypes.add('a');
        }
        if(dType.isSelected())
        {
            tempTypes.add('d');
        }

        return tempTypes;
    }

    public void backToMenuButtonClick(MouseEvent mouseEvent) throws Exception{
        Parent parent = FXMLLoader.load(getClass().getResource("/sample/exerciseSelectionMenu.fxml"));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) backToMenuButton.getScene().getWindow();
        defaultScene.setScene(scene);
    }

}
