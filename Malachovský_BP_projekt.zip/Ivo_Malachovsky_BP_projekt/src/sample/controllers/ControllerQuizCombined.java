package sample.controllers;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import sample.elements.QuestionQuiz;
import sample.elements.QuizQuestionGenerator;

import java.util.ArrayList;
import java.util.Random;

public class ControllerQuizCombined {
    public ImageView noteDisplay;
    public ComboBox answerSelection;
    public Label definition;
    private String answer;
    private int image;

    public Rectangle imageOutline;

    private int displayedImage;
    ArrayList<Integer> availableImages = new ArrayList<Integer>();

    public Label answerVerificationLabelPicture, answerVerificationLabelName;
    public Button checkAnswerBtn, showCorrectImage, previousSymbol, nextSymbol;

    //region Exercise
    private int finalScore = 0;
    private int answeredQuestions = 0;
    private boolean infiniteQuestions;

    private ArrayList<QuestionQuiz> questions;
    private int questionIndex=0;
    //endregion

    private QuizQuestionGenerator generator;

    public void setAnswer(ArrayList<QuestionQuiz> questions, int questionIndex, int finalScore, int answeredQuestions, QuizQuestionGenerator generator, boolean infiniteQuestions)
    {
        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.generator = generator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<QuestionQuiz>(questions);

        answer = questions.get(questionIndex).getName();
        image = questions.get(questionIndex).getImageId();

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabelPicture.setText("");
        answerVerificationLabelName.setText("");

        if(answer != null) {
            Random rnd = new Random();

            answerSelection.getItems().addAll(generator.getAnswers());
            answerSelection.getSelectionModel().selectFirst();

            availableImages = generator.getAvailableQuestions();
            displayedImage = rnd.nextInt(availableImages.size());

            Image image = new Image(getClass().getResourceAsStream("/sample/symbols/"+availableImages.get(displayedImage)+".png"));
            noteDisplay.setImage(image);

            definition.setText(questions.get(questionIndex).getDescription());
        }
    }

    public void initialize()
    {

    }


    public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {
        if(checkAnswerBtn.getText().equals("Zkontrolovat")) {

            answerVerificationLabelName.setText("Správně vybraný pojem");
            answerVerificationLabelPicture.setText("Správně vybraný obrázek");
            answerVerificationLabelName.setTextFill(Color.web("#049F0B"));
            answerVerificationLabelPicture.setTextFill(Color.web("#049F0B"));
            previousSymbol.setVisible(false);
            nextSymbol.setVisible(false);

            if(answer.equals(answerSelection.getValue()) && availableImages.get(displayedImage) == image)
            {
                finalScore++;
            }
            else
            {
                if(!(answer.equals(answerSelection.getValue()))) {
                    answerVerificationLabelName.setText("Špatně vybraný pojem! Správná odpověď je: " + answer);
                    answerVerificationLabelName.setTextFill(Color.web("#F2160D"));
                }
                if (!(availableImages.get(displayedImage) == image))
                {
                    answerVerificationLabelPicture.setText("Špatně vybraný obrázek!");
                    answerVerificationLabelPicture.setTextFill(Color.web("#F2160D"));
                    showCorrectImage.setVisible(true);
                }
            }
            answeredQuestions++;

            checkAnswerBtn.setText("Další");
        }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<QuestionQuiz>(generator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/quizCombined.fxml"));
            root = loader.load();
            ControllerQuizCombined controllerQuizCombined = loader.getController();
            controllerQuizCombined.setAnswer(questions, questionIndex, finalScore, answeredQuestions, generator , infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }

    public void previousClick(MouseEvent mouseEvent) {
        displayedImage--;
        if(displayedImage < 0)
        {
            displayedImage = availableImages.size()-1;
        }

        Image image = new Image(getClass().getResourceAsStream("/sample/symbols/"+availableImages.get(displayedImage)+".png"));
        noteDisplay.setImage(image);
    }

    public void nextClick(MouseEvent mouseEvent) {
        displayedImage++;
        if(displayedImage >= availableImages.size())
        {
            displayedImage = 0;
        }

        Image image = new Image(getClass().getResourceAsStream("/sample/symbols/"+availableImages.get(displayedImage)+".png"));
        noteDisplay.setImage(image);

    }

    public void showCorrectImageEvent(MouseEvent mouseEvent) {
        Image img = new Image(getClass().getResourceAsStream("/sample/symbols/"+image+".png"));
        noteDisplay.setImage(img);
        imageOutline.setStroke(Color.web("0x73aa73ff"));
        showCorrectImage.setVisible(false);
    }
}
