package sample.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import sample.elements.KeyboardDoubleController;
import sample.exercises.ScaleNameKey.ScaleNameKeyGenerator;
import sample.exercises.ScaleNameKey.ScaleNameKeyQuestion;
import sample.logic.AllNotes;
import sample.logic.KeyboardLogic;
import sample.logic.NoteOperations;
import sample.logic.Scale;

import java.io.IOException;
import java.util.ArrayList;

public class ControllerScaleNameKey {
    public Button submitAnswer, showAnswer;
    public Label questionLabel, answerVerificationLabel;

    @FXML
    private KeyboardDoubleController keyboardDoubleScaleController;

    private Scale answer = new Scale();
    private AllNotes allNotes = new AllNotes();

    private int finalScore = 0;
    private int answeredQuestions = 0;

    private boolean infiniteQuestions;

    private ScaleNameKeyGenerator scaleNameKeyGenerator;

    private ArrayList<ScaleNameKeyQuestion> questions;
    private int questionIndex=0;

    public void setAnswer(ArrayList<ScaleNameKeyQuestion> questions, int questionIndex, int finalScore, int answeredQuestions, ScaleNameKeyGenerator scaleNameKeyGenerator, boolean infiniteQuestions)
    {
        NoteOperations nOp = new NoteOperations();

        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.scaleNameKeyGenerator = scaleNameKeyGenerator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<ScaleNameKeyQuestion>(questions);

        answer.generateScale(questions.get(questionIndex).getScaleType(), questions.get(questionIndex).getRootNote());

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabel.setText("");

        if(answer != null) {
            questionLabel.setText("Zapište stupnici: " + answer.getName());
        }
    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/scaleNameKey.fxml"));
            root = loader.load();
            ControllerScaleNameKey controllerScaleNameKey = loader.getController();
            controllerScaleNameKey.setAnswer(questions, questionIndex, finalScore, answeredQuestions, scaleNameKeyGenerator, infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


    public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {

        if(submitAnswer.getText().equals("Zkontrolovat")) {
            if(keyboardDoubleScaleController.checkAnswer(answer.getScaleNotes()))
            {
                 answerVerificationLabel.setText("Správná odpověď");
                 answerVerificationLabel.setTextFill(Color.web("#049F0B"));
                 keyboardDoubleScaleController.setActiveKeyboard(false);
                 finalScore++;
                 answeredQuestions++;
            }
            else
            {
                answerVerificationLabel.setText("Špatná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#F2160D"));
                showAnswer.setVisible(true);
                keyboardDoubleScaleController.setActiveKeyboard(false);
                answeredQuestions++;
            }
                submitAnswer.setText("Další");
            }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<ScaleNameKeyQuestion>(scaleNameKeyGenerator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }

    public void showAnswerClick(MouseEvent mouseEvent) {
        keyboardDoubleScaleController.highlightKeys(answer.getScaleNotes());
        showAnswer.setVisible(false);
    }
}
