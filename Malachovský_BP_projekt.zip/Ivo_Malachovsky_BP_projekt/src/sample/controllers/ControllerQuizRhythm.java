package sample.controllers;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import sample.exercises.QuizRythm.QuizRythmGenerator;
import sample.exercises.QuizRythm.QuizRythmQuestion;


import java.io.File;
import java.util.ArrayList;
import java.util.Random;

public class ControllerQuizRhythm {

    public ImageView noteDisplay;
    public ComboBox answerBox;
    private QuizRythmQuestion answer;

    public Label answerVerificationLabel;
    public Button checkAnswerBtn;

    //region Exercise
    private int finalScore = 0;
    private int answeredQuestions = 0;
    private boolean infiniteQuestions;

    private ArrayList<QuizRythmQuestion> questions;
    private int questionIndex=0;
    //endregion

    private QuizRythmGenerator quizRythmGenerator;

    public void setAnswer(ArrayList<QuizRythmQuestion> questions, int questionIndex, int finalScore, int answeredQuestions, QuizRythmGenerator quizRythmGenerator, boolean infiniteQuestions)
    {
        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.quizRythmGenerator = quizRythmGenerator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<QuizRythmQuestion>(questions);

        answer = new QuizRythmQuestion(questions.get(questionIndex).getNoteLengthName(), questions.get(questionIndex).getPictureId());

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabel.setText("");

        if(answer != null) {
            answerBox.getItems().addAll(quizRythmGenerator.getNoteLengths());
            answerBox.getSelectionModel().selectFirst();
            Image image = new Image(getClass().getResourceAsStream("/sample/notes/"+ answer.getPictureId()+".png"));
            noteDisplay.setImage(image);
        }
    }


    public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {
        if(checkAnswerBtn.getText().equals("Zkontrolovat")) {

            if(answer.getNoteLengthName().equals(answerBox.getValue()))
            {
                answerVerificationLabel.setText("Správná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#049F0B"));
                finalScore++;
            }
            else
            {
                answerVerificationLabel.setText("Špatná odpověď! Správná odpověď je: "+answer.getNoteLengthName());
                answerVerificationLabel.setTextFill(Color.web("#F2160D"));
            }
            answeredQuestions++;

            checkAnswerBtn.setText("Další");
        }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<QuizRythmQuestion>(quizRythmGenerator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/quizRhythm.fxml"));
            root = loader.load();
            ControllerQuizRhythm controllerQuizRhythm = loader.getController();
            controllerQuizRhythm.setAnswer(questions, questionIndex, finalScore, answeredQuestions, quizRythmGenerator , infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }
}
