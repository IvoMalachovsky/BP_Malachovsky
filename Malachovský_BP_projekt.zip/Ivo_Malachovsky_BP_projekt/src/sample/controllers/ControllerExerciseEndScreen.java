package sample.controllers;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ControllerExerciseEndScreen {

    public Label scoreLabel;
    public Button menuButton;

    public void setScore(int score, int numberOfQuestions)
    {
        scoreLabel.setText("Skóre je: " +score+"/"+numberOfQuestions);
    }

    public void backToMenuEvent(MouseEvent mouseEvent) throws Exception{
        Parent mainMenu = FXMLLoader.load(getClass().getResource("/sample/exerciseSelectionMenu.fxml"));
        Scene scene = new Scene(mainMenu);
        Stage defaultScene = (Stage) menuButton.getScene().getWindow();
        defaultScene.setScene(scene);
    }
}
