package sample.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.stage.Window;
import sample.elements.KeyboardDoubleController;
import sample.exercises.ChordNameKey.ChordNameKeyGenerator;
import sample.exercises.ChordNameKey.ChordNameKeyQuestion;
import sample.logic.AllNotes;
import sample.logic.Chord;
import sample.logic.KeyboardLogic;
import sample.logic.NoteOperations;


import java.util.ArrayList;

public class ControllerChordNameKeyboard {
    public Button submitAnswer, showAnswer;
    public Label questionLabel, answerVerificationLabel;

    private Chord answer = new Chord();
    private AllNotes allNotes = new AllNotes();

    private int finalScore = 0;
    private int answeredQuestions = 0;

    private boolean infiniteQuestions;

    private ChordNameKeyGenerator chordNameKeyGenerator;

    private ArrayList<ChordNameKeyQuestion> questions;
    private int questionIndex=0;

    @FXML private KeyboardDoubleController keyboardDoubleOneController;

    public void setAnswer(ArrayList<ChordNameKeyQuestion> questions, int questionIndex, int finalScore, int answeredQuestions, ChordNameKeyGenerator chordNameKeyGenerator, boolean infiniteQuestions)
    {
        NoteOperations nOp = new NoteOperations();

        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.chordNameKeyGenerator = chordNameKeyGenerator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<ChordNameKeyQuestion>(questions);

        answer.generateChord(questions.get(questionIndex).getChordType(), questions.get(questionIndex).getRootNote(), questions.get(questionIndex).getInversion());

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabel.setText("");

        if(answer != null) {
            questionLabel.setText("Zapište akord: " + answer.getName() +" | inverze: "+answer.getInversion());
        }
    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/chordNameKeyboard.fxml"));
            root = loader.load();
            ControllerChordNameKeyboard controllerChordNameKeyboard = loader.getController();
            controllerChordNameKeyboard.setAnswer(questions, questionIndex, finalScore, answeredQuestions, chordNameKeyGenerator, infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }


     public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {

        if(submitAnswer.getText().equals("Zkontrolovat")) {

            if(keyboardDoubleOneController.checkAnswer(answer.getNotes()))
            {
                answerVerificationLabel.setText("Správná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#049F0B"));
                keyboardDoubleOneController.setActiveKeyboard(false);
                finalScore++;
                answeredQuestions++;
            }
            else
            {
                answerVerificationLabel.setText("Špatná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#F2160D"));
                showAnswer.setVisible(true);
                keyboardDoubleOneController.setActiveKeyboard(false);
                answeredQuestions++;
            }
            submitAnswer.setText("Další");
        }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<ChordNameKeyQuestion>(chordNameKeyGenerator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }

    public void showAnswerClick(MouseEvent mouseEvent) {
        keyboardDoubleOneController.highlightKeys(answer.getNotes());
        showAnswer.setVisible(false);
    }

}
