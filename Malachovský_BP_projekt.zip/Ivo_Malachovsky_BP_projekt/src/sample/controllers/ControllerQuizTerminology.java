package sample.controllers;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import sample.elements.QuestionQuiz;
import sample.elements.QuizQuestionGenerator;

import java.util.ArrayList;

public class ControllerQuizTerminology {

    public Label definition;
    public ComboBox answerSelection;
    private String answer;

    public Label answerVerificationLabel;
    public Button checkAnswerBtn;

    //region Exercise
    private int finalScore = 0;
    private int answeredQuestions = 0;
    private boolean infiniteQuestions;

    private ArrayList<QuestionQuiz> questions;
    private int questionIndex=0;
    //endregion

    private QuizQuestionGenerator generator;

    public void setAnswer(ArrayList<QuestionQuiz> questions, int questionIndex, int finalScore, int answeredQuestions, QuizQuestionGenerator generator, boolean infiniteQuestions)
    {
        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.generator = generator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<QuestionQuiz>(questions);

        answer = questions.get(questionIndex).getName();

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabel.setText("");

        if(answer != null) {
            answerSelection.getItems().addAll(generator.getAnswers());
            answerSelection.getSelectionModel().selectFirst();

            definition.setText(questions.get(questionIndex).getDescription());
        }
    }

    public void initialize()
    {

    }


    public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {
        if(checkAnswerBtn.getText().equals("Zkontrolovat")) {

            if(answer.equals(answerSelection.getValue()))
            {
                answerVerificationLabel.setText("Správná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#049F0B"));
                finalScore++;
            }
            else
            {
                answerVerificationLabel.setText("Špatná odpověď! Správná odpověď je: "+answer);
                answerVerificationLabel.setTextFill(Color.web("#F2160D"));
            }
            answeredQuestions++;

            checkAnswerBtn.setText("Další");
        }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<QuestionQuiz>(generator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/quizTerminology.fxml"));
            root = loader.load();
            ControllerQuizTerminology controllerQuizTerminology = loader.getController();
            controllerQuizTerminology.setAnswer(questions, questionIndex, finalScore, answeredQuestions, generator, infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }
}
