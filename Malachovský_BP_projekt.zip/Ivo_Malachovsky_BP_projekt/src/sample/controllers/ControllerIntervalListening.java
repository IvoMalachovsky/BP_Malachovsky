package sample.controllers;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import sample.exercises.IntervalListening.IntervalListeningGenerator;
import sample.exercises.IntervalListening.IntervalListeningQuestion;
import sample.logic.AllNotes;
import sample.logic.Interval;
import sample.logic.Note;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;

public class ControllerIntervalListening {
    private MediaPlayer mediaPlayer;

    public ComboBox intervalTypeBox, intervalNameBox;
    private Interval answer = new Interval();

    public Button playFirst, playSecond, playBoth;

    public Label answerVerificationLabel, intervalTask;
    public Button checkAnswerBtn;

    //region Exercise
    private int finalScore = 0;
    private int answeredQuestions = 0;
    private boolean infiniteQuestions;

    private ArrayList<IntervalListeningQuestion> questions;
    private int questionIndex=0;
    //endregion

    private IntervalListeningGenerator intervalListeningGenerator;

    public void setAnswer(ArrayList<IntervalListeningQuestion> questions, int questionIndex, int finalScore, int answeredQuestions, IntervalListeningGenerator intervalListeningGenerator, boolean infiniteQuestions)
    {
        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.intervalListeningGenerator = intervalListeningGenerator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<IntervalListeningQuestion>(questions);

        answer.generateInterval(questions.get(questionIndex).getRootNote(), questions.get(questionIndex).getIntervalName(), questions.get(questionIndex).getIntervalType(), questions.get(questionIndex).isAscending());

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabel.setText("");

        Interval interval = new Interval();

        intervalNameBox.getItems().addAll(interval.translateAllNumbers(intervalListeningGenerator.getIntervalNames()));
        intervalTypeBox.getItems().addAll(interval.translateIntervalTypes(intervalListeningGenerator.getIntervalTypes(), intervalListeningGenerator.getIntervalNames()));

        intervalNameBox.getSelectionModel().selectFirst();
        intervalTypeBox.getSelectionModel().selectFirst();

        if(answer != null) {
            ArrayList<String> notes = new ArrayList<String>();
            notes.add(answer.getNoteOne()); notes.add(answer.getNoteTwo());

            if(!answer.isAscending()) {intervalTask.setText("Sestupný interval");}
        }
    }

    public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {
        if(checkAnswerBtn.getText().equals("Zkontrolovat")) {
            String providedAnswer = intervalTypeBox.getValue()+" "+intervalNameBox.getValue();

            if(answer.getIntervalName().equals(providedAnswer))
            {
                answerVerificationLabel.setText("Správná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#049F0B"));
                finalScore++;
            }
            else
            {
                answerVerificationLabel.setText("Špatná odpověď! Správná odpověď je: "+answer.getIntervalName());
                answerVerificationLabel.setTextFill(Color.web("#F2160D"));
            }
            answeredQuestions++;

            checkAnswerBtn.setText("Další");
        }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<IntervalListeningQuestion>(intervalListeningGenerator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/intervalListening.fxml"));
            root = loader.load();
            ControllerIntervalListening controllerIntervalListening = loader.getController();
            controllerIntervalListening.setAnswer(questions, questionIndex, finalScore, answeredQuestions, intervalListeningGenerator, infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }

    public void playFirstButtonClick(MouseEvent mouseEvent) {
        AllNotes allNotes = new AllNotes();
        Note note1 = allNotes.translateStringNote(answer.getNoteOne());

        playSound("/sample/sounds/"+note1.getId()+".mp3");
    }

    public void playSecondButtonClick(MouseEvent mouseEvent) {
        AllNotes allNotes = new AllNotes();
        Note note2 = allNotes.translateStringNote(answer.getNoteTwo());

        playSound("/sample/sounds/"+note2.getId()+".mp3");
    }

    private void playSound(String path)
    {
        try {
            URL url = getClass().getResource(path);
            File file = new File(url.getPath());
            Media media;

            media = new Media(file.toURI().toString());
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();
        }
        catch (Exception e){
            System.out.println("Chyba: "+ e.getClass().getName() + "   "+ e);
        }
    }

    public void playBothButtonClick(MouseEvent mouseEvent) {
        playFirstButtonClick(mouseEvent);
        playSecondButtonClick(mouseEvent);
    }
}
