package sample.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import sample.elements.StaffController;
import sample.exercises.ScaleBarName.ScaleBarNameGenerator;
import sample.exercises.ScaleBarName.ScaleBarNameQuestion;
import sample.logic.GeneralGeneration;
import sample.logic.Scale;

import java.util.ArrayList;

public class ControllerScalesBarName {

    public ComboBox<String> scaleName, scaleType, scaleAccidental;
    private Scale answer = new Scale();

    @FXML
    private StaffController staffOneController;
    @FXML
    private StaffController staffTwoController;

    public Label answerVerificationLabel;
    public Button checkAnswerBtn;

    //region Exercise
    private int finalScore = 0;
    private int answeredQuestions = 0;
    private boolean infiniteQuestions;

    private ArrayList<ScaleBarNameQuestion> questions;
    private int questionIndex=0;
    //endregion

    private ScaleBarNameGenerator scaleBarNameGenerator;

    public void setAnswer(ArrayList<ScaleBarNameQuestion> questions, int questionIndex, int finalScore, int answeredQuestions, ScaleBarNameGenerator scaleBarNameGenerator, boolean infiniteQuestions)
    {
        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.scaleBarNameGenerator = scaleBarNameGenerator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<ScaleBarNameQuestion>(questions);

        answer.generateScale(questions.get(questionIndex).getScaleType(), questions.get(questionIndex).getRootNote());

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabel.setText("");

        GeneralGeneration gg = new GeneralGeneration();

        scaleName.getItems().addAll(gg.viableNoteAnswers(scaleBarNameGenerator.getNotes()));
        scaleType.getItems().addAll(scaleBarNameGenerator.getTypes());
        scaleAccidental.getItems().addAll(gg.viableAccidentalsAnswers(scaleBarNameGenerator.getNotes()));

        scaleName.getSelectionModel().selectFirst();
        scaleType.getSelectionModel().selectFirst();
        scaleAccidental.getSelectionModel().selectFirst();

        if(answer != null) {
            staffOneController.start(answer.getScaleNotes(),true, questions.get(questionIndex).getKey().equals("bass"));
            staffTwoController.start(answer.getScaleNotesDown(),true, questions.get(questionIndex).getKey().equals("bass"));
        }

    }

    public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {
        if(checkAnswerBtn.getText().equals("Zkontrolovat")) {
            String providedAnswer="";

            providedAnswer = scaleName.getValue() + scaleAccidental.getValue()+ " " + scaleType.getValue();

            if(answer.getName().equals(providedAnswer))
            {
                answerVerificationLabel.setText("Správná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#049F0B"));
                finalScore++;
            }
            else
            {
                answerVerificationLabel.setText("Špatná odpověď! Správná odpověď je: "+answer.getName());
                answerVerificationLabel.setTextFill(Color.web("#F2160D"));
            }
            answeredQuestions++;

            checkAnswerBtn.setText("Další");
        }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<ScaleBarNameQuestion>(scaleBarNameGenerator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/scalesBarName.fxml"));
            root = loader.load();
            ControllerScalesBarName controllerScalesBarName = loader.getController();
            controllerScalesBarName.setAnswer(questions, questionIndex, finalScore, answeredQuestions, scaleBarNameGenerator, infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }
}
