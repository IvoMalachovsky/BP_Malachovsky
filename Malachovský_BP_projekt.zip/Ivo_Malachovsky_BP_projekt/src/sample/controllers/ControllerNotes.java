package sample.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import sample.elements.KeyboardSingleController;
import sample.elements.StaffController;
import sample.exercises.NotesExercise.NotesGenerator;
import sample.exercises.NotesExercise.NotesQuestion;
import sample.logic.AllNotes;
import sample.logic.NoteOperations;

import java.util.ArrayList;

public class ControllerNotes {
    private String answer;
    private String providedAnswer="";

    @FXML
    private StaffController largeStaffNotesController;

    @FXML
    private KeyboardSingleController keyboardSingleNotesController;

    public Label answerVerificationLabel;
    public Button checkAnswerBtn;

    //region Exercise
    private int finalScore = 0;
    private int answeredQuestions = 0;
    private boolean infiniteQuestions;

    private ArrayList<NotesQuestion> questions;
    private int questionIndex=0;
    //endregion

    private NotesGenerator notesGenerator;

    public void setAnswer(ArrayList<NotesQuestion> questions, int questionIndex, int finalScore, int answeredQuestions, NotesGenerator notesGenerator, boolean infiniteQuestions)
    {
        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.notesGenerator = notesGenerator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<NotesQuestion>(questions);

        answer = questions.get(questionIndex).getNote();
        try {
            AllNotes allNotes = new AllNotes();
            allNotes.translateStringNote(answer).getName();
        }
        catch (Exception e)
        {
            NoteOperations nop = new NoteOperations();
            answer = nop.changeOctave(answer, 1);
        }

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabel.setText("");

        if(answer != null) {
            switchToAccidentals();

            ArrayList<String> answers = new ArrayList<String>();
            answers.add(answer);

            largeStaffNotesController.start(answers,false, questions.get(questionIndex).getKey().equals("bass"));
        }
    }


    public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {
        AllNotes allNotes = new AllNotes();
        NoteOperations nOp = new NoteOperations();

        if(checkAnswerBtn.getText().equals("Zkontrolovat")) {

            if(keyboardSingleNotesController.getProvidedAnswer().length() > 0) {
                providedAnswer = keyboardSingleNotesController.getProvidedAnswer().substring(0, 1) + "1" +
                        keyboardSingleNotesController.getProvidedAnswer().substring(2);
            }

            if(checkAnswer())
            {
                answerVerificationLabel.setText("Správná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#049F0B"));
                finalScore++;
            }
            else
            {
                answerVerificationLabel.setText("Špatná odpověď! Jedná se o notu: " + nOp.translateAccidentalToSuffix(nOp.removeOctaveNumber(answer)));
                answerVerificationLabel.setTextFill(Color.web("#F2160D"));
            }
            answeredQuestions++;

            checkAnswerBtn.setText("Další");
        }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<NotesQuestion>(notesGenerator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    private boolean checkAnswer()
    {
        AllNotes allNotes = new AllNotes();
        boolean value = false;

        if(!providedAnswer.equals(""))
        {
            if(allNotes.translateStringNote(answer).getName().equals(allNotes.translateStringNote(providedAnswer).getName()))
            {
                value = true;
            }
        }

        return value;

    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/notes.fxml"));
            root = loader.load();
            ControllerNotes controllerNotes = loader.getController();
            controllerNotes.setAnswer(questions, questionIndex, finalScore, answeredQuestions, notesGenerator, infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }

    private void switchToAccidentals()
    {
        String symbols="";
        String newSymbols = "";


            if(answer.length() > 2)
            {
                symbols = answer.substring(2);
            }
            else
            {
                symbols = "";
            }
            for (int j = 0; j<symbols.length(); j++)
            {
                if(symbols.charAt(j) == 's' || symbols.charAt(j) == '#')
                {
                    newSymbols = newSymbols + "#";
                }
                else if(symbols.charAt(j) == 'f' || symbols.charAt(j) == 'b')
                {
                    newSymbols = newSymbols + "b";
                }
            }
            answer = answer.substring(0,2)+newSymbols;
    }

}
