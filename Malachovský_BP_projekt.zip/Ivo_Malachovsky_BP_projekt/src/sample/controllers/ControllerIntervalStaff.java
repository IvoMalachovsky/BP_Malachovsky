package sample.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import sample.elements.StaffController;
import sample.exercises.IntervalStaff.IntervalStaffGenerator;
import sample.exercises.IntervalStaff.IntervalStaffQuestion;
import sample.logic.Interval;

import java.util.ArrayList;

public class ControllerIntervalStaff {
    public ComboBox intervalTypeBox, intervalNameBox;
    private Interval answer = new Interval();

    @FXML
    private StaffController largeStaffIntervalController;

    public Label answerVerificationLabel, intervalTask;
    public Button checkAnswerBtn;

    //region Exercise
    private int finalScore = 0;
    private int answeredQuestions = 0;
    private boolean infiniteQuestions;

    private ArrayList<IntervalStaffQuestion> questions;
    private int questionIndex=0;
    //endregion

    private IntervalStaffGenerator intervalStaffGenerator;

    public void setAnswer(ArrayList<IntervalStaffQuestion> questions, int questionIndex, int finalScore, int answeredQuestions, IntervalStaffGenerator intervalStaffGenerator, boolean infiniteQuestions)
    {
        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.intervalStaffGenerator = intervalStaffGenerator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<IntervalStaffQuestion>(questions);

        answer.generateInterval(questions.get(questionIndex).getRootNote(), questions.get(questionIndex).getIntervalName(), questions.get(questionIndex).getIntervalType(), questions.get(questionIndex).isAscending());

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabel.setText("");

        Interval interval = new Interval();

        intervalNameBox.getItems().addAll(interval.translateAllNumbers(intervalStaffGenerator.getIntervalNames()));
        intervalTypeBox.getItems().addAll(interval.translateIntervalTypes(intervalStaffGenerator.getIntervalTypes(), intervalStaffGenerator.getIntervalNames()));

        intervalNameBox.getSelectionModel().selectFirst();
        intervalTypeBox.getSelectionModel().selectFirst();

        if(answer != null) {
            ArrayList<String> notes = new ArrayList<String>();
            notes.add(answer.getNoteOne()); notes.add(answer.getNoteTwo());

            largeStaffIntervalController.start(notes,false, questions.get(questionIndex).getKey().equals("bass"));
            if(!answer.isAscending()) {intervalTask.setText("Sestupný interval");}
        }
    }

    public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {
        if(checkAnswerBtn.getText().equals("Zkontrolovat")) {
            String providedAnswer = intervalTypeBox.getValue()+" "+intervalNameBox.getValue();
            if(answer.getIntervalName().equals(providedAnswer))
            {
                answerVerificationLabel.setText("Správná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#049F0B"));
                finalScore++;
            }
            else
            {
                answerVerificationLabel.setText("Špatná odpověď! Správná odpověď je: "+answer.getIntervalName());
                answerVerificationLabel.setTextFill(Color.web("#F2160D"));
            }
            answeredQuestions++;

            checkAnswerBtn.setText("Další");
        }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<IntervalStaffQuestion>(intervalStaffGenerator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/intervalStaff.fxml"));
            root = loader.load();
            ControllerIntervalStaff controllerIntervalStaff = loader.getController();
            controllerIntervalStaff.setAnswer(questions, questionIndex, finalScore, answeredQuestions, intervalStaffGenerator, infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }
}
