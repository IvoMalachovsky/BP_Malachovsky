package sample.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import sample.elements.StaffController;
import sample.exercises.ChordStaffName.ChordStaffNameGenerator;
import sample.exercises.ChordStaffName.ChordStaffNameQuestion;
import sample.logic.Chord;
import sample.logic.GeneralGeneration;

import java.util.ArrayList;

public class ControllerChordNameBar {
    private Chord answer = new Chord();

    public Label answerVerificationLabel;
    public Button checkAnswerBtn;
    public ComboBox chordNameBox, chordSymbolBox, chordTypeBox, chordInversionBox;

    @FXML
    private StaffController largeStaffChordController;

    //region Exercise
    private int finalScore = 0;
    private int answeredQuestions = 0;
    private boolean infiniteQuestions;

    private ArrayList<ChordStaffNameQuestion> questions;
    private int questionIndex=0;
    //endregion

    private ChordStaffNameGenerator chordStaffNameGenerator;

    public void setAnswer(ArrayList<ChordStaffNameQuestion> questions, int questionIndex, int finalScore, int answeredQuestions, ChordStaffNameGenerator chordStaffNameGenerator, boolean infiniteQuestions)
    {
        this.finalScore = finalScore;
        this.answeredQuestions = answeredQuestions;
        this.chordStaffNameGenerator = chordStaffNameGenerator;
        this.infiniteQuestions = infiniteQuestions;
        this.questions = new ArrayList<ChordStaffNameQuestion>(questions);

        answer.generateChord(questions.get(questionIndex).getChordType(), questions.get(questionIndex).getRootNote(), questions.get(questionIndex).getInversion());

        this.questionIndex = questionIndex;
        this.questionIndex++;

        answerVerificationLabel.setText("");

        GeneralGeneration gg = new GeneralGeneration();

        chordNameBox.getItems().addAll(gg.viableNoteAnswers(chordStaffNameGenerator.getNotes()));
        chordTypeBox.getItems().addAll(chordStaffNameGenerator.getTypes());
        chordSymbolBox.getItems().addAll(gg.viableAccidentalsAnswers(chordStaffNameGenerator.getNotes()));
        chordInversionBox.getItems().addAll(chordStaffNameGenerator.getInversion());

        chordNameBox.getSelectionModel().selectFirst();
        chordTypeBox.getSelectionModel().selectFirst();
        chordSymbolBox.getSelectionModel().selectFirst();
        chordInversionBox.getSelectionModel().selectFirst();

        if(answer != null) {
            largeStaffChordController.start(answer.getNotes(), false, questions.get(questionIndex).getKey().equals("bass"), answer.getName());
        }
    }

    private String createAnswer()
    {
        return chordNameBox.getValue() +""+ chordSymbolBox.getValue()+" "+chordTypeBox.getValue()+" "+chordInversionBox.getValue();
    }


    public void onSubmitAnswerClickEvent(MouseEvent mouseEvent) throws Exception {
        if(checkAnswerBtn.getText().equals("Zkontrolovat")) {
            if((answer.getName()+" "+answer.getInversion()).equals(createAnswer()))
            {
                answerVerificationLabel.setText("Správná odpověď");
                answerVerificationLabel.setTextFill(Color.web("#049F0B"));
                finalScore++;
            }
            else
            {
                answerVerificationLabel.setText("Špatná odpověď! Správná odpověď je: "+answer.getName()+" | Inverze: "+answer.getInversion());
                answerVerificationLabel.setTextFill(Color.web("#F2160D"));
            }
            answeredQuestions++;

            checkAnswerBtn.setText("Další");
        }
        else
        {
            if(questions.size() > questionIndex) {
                loadNextScene(mouseEvent, true);
            }
            else if(!(questions.size() > questionIndex) && infiniteQuestions)
            {
                questions = new ArrayList<ChordStaffNameQuestion>(chordStaffNameGenerator.generateQuestions(20));
                questionIndex = 0;

                loadNextScene(mouseEvent, true);
            }
            else
            {
                loadNextScene(mouseEvent, false);
            }
        }
    }

    private void loadNextScene(MouseEvent mouseEvent, boolean nextQuestion) throws Exception
    {
        Parent root;
        Scene scene;
        Stage stage;

        if(nextQuestion) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/chordNameBar.fxml"));
            root = loader.load();
            ControllerChordNameBar controllerChordNameBar = loader.getController();
            controllerChordNameBar.setAnswer(questions, questionIndex, finalScore, answeredQuestions, chordStaffNameGenerator, infiniteQuestions);

        }
        else
        {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/sample/fxmls/exerciseEndScreen.fxml"));
            root = loader.load();
            ControllerExerciseEndScreen controllerExerciseEndScreen = loader.getController();
            controllerExerciseEndScreen.setScore(finalScore, answeredQuestions);
        }

        stage = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void endExerciseEvent(MouseEvent mouseEvent) throws Exception {
        loadNextScene(mouseEvent, false);
    }
}
