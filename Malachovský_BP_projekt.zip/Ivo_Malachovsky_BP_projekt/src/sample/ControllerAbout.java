package sample;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.util.ArrayList;

public class ControllerAbout {

    public Button back, nextPage, previousPage;
    public Label credits1;

    private ArrayList<String> pages = new ArrayList<String>();
    private int currentPage = 0;

    public void initialize()
    {
        pages.add("Tečka\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/noty-pomlky-a-rytmus\n" +
                "-\tObrázek(zdroj): https://en.wikipedia.org/wiki/File:Dotted_notes3.svg (veřejná doména)\n" +
                "\n" +
                "Ligatura\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/noty-pomlky-a-rytmus\n" +
                "-\tObrázek(zdroj): Tie-music.png od autora: Special-T, získáno z: https://en.wikipedia.org/wiki/File:Tie-music.png, podle licence: https://creativecommons.org/licenses/by-sa/4.0/, neupraveno\n" +
                "\n" +
                "Staccato\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/artikulace\n" +
                "-\tObrázek(zdroj): Music-staccato.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-staccato.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno  \n" +
                "\n" +
                "Pomlka\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/artikulace\n" +
                "-\tObrázek(zdroj): Music-wholerest.svg od autora: DustyComputer, získáno z: https://en.wikipedia.org/wiki/File:Music-wholerest.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno \n" +
                "\n" +
                "Forte\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/dynamika\n" +
                "-\tObrázek(zdroj):  https://en.wikipedia.org/wiki/File:Music_dynamic_forte.svg (veřejná doména) + Music-staccato.svg od autora: Denelson83 a Ekips39 , získáno z: https://en.wikipedia.org/wiki/File:Music-staccato.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – kombinace s jiným obrázkem  \n" +
                "\n" +
                "Takt\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/notová-osnova\n" +
                "-\tObrázek(zdroj): Music-timesig.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-timesig.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno \n" +
                "\n" +
                "C klíč\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/notová-osnova\n" +
                "-\tObrázek(zdroj): Alto-clef.svg od autora: Special-T, získáno z: https://en.wikipedia.org/wiki/File:Alto-clef.svg, podle licence: https://creativecommons.org/licenses/by-sa/4.0/, neupraveno\n" +
                "\n" +
                "Legato\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/artikulace\n" +
                "-\tObrázek(zdroj): Music-slur.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-slur.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno\n" +
                "\n" +
                "Korunka\n" +
                "-\tDefinice(zdroj): https://cs.khanacademy.org/humanities/music/music-basics2/notes-rhythm/a/glossary-of-musical-terms\n" +
                "-\tObrázek(zdroj): Music-fermata.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-fermata.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno \n" +
                "\n");

        pages.add("Repetice\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/opakování-a-odskoky\n" +
                "-\tObrázek(zdroj): Vaderjacob-Zanaq.png od autora: Zanaq, získáno z: https://commons.wikimedia.org/wiki/File:Vaderjacob-Zanaq.png, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – oříznuté a přidány šipky\n" +
                "\n" +
                "Akcent\n" +
                "-\tDefinice(zdroj): https://www.topmuzika.cz/magazin/co-je-akcent/\n" +
                "-\tObrázek(zdroj): Music-marcato.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-marcato.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno \n" +
                "\n" +
                "Piano\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/dynamika\n" +
                "-\tObrázek(zdroj): https://en.wikipedia.org/wiki/File:Music_dynamic_piano.svg (veřejná doména) + Music-staccato.svg od autora: Denelson83 a Ekips39 , získáno z: https://en.wikipedia.org/wiki/File:Music-staccato.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – kombinace s jiným obrázkem   \n" +
                "\n" +
                "Triola\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Seznam_hudebních_pojmů\n" +
                "-\tObrázek(zdroj): Music-triplet.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-triplet.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno \n" +
                "\n" +
                "Da capo al fine\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/opakování-a-odskoky\n" +
                "-\tObrázek(zdroj): Da capo al fine.png od autora: Artlejandra, získáno z: https://commons.wikimedia.org/wiki/File:Da_capo_al_fine.png, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – oříznuto\n" +
                "\n" +
                "Primavolta a sekundavolta\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Prima_volta\n" +
                "-\tObrázek(zdroj): Repeat Music II.png od autora: مهدی بزرگمهر, získáno z: https://commons.wikimedia.org/wiki/File:Repeat_Music_II.png, podle licence: https://creativecommons.org/licenses/by-sa/4.0/, upraveno – oříznuto\n" +
                "\n" +
                "Tenuto\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/artikulace\n" +
                "-\tObrázek(zdroj): Music-tenuto.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-tenuto.svg podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno \n" +
                "\n" +
                "Zvýraznění:\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/dynamika\n" +
                "-\tObrázek(zdroj): Music-strong-marcato.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-strong-marcato.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno\n" +
                "\n" +
                "Glissando\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/artikulace\n" +
                "-\tObrázek(zdroj): Music-glissando.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-glissando.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno\n");

        pages.add("Arpeggio\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/artikulace\n" +
                "-\tObrázek(zdroj): Music-arpeggio.svg od autora: Sbrools, získáno z: https://en.wikipedia.org/wiki/File:Music-arpeggio.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno\n" +
                "\n" +
                "Tremolo\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/artikulace\n" +
                "-\tObrázek(zdroj): https://en.wikipedia.org/wiki/File:Music-tremolo.svg (veřejná doména)\n" +
                "\n" +
                "Nátryl\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/melodické-ozdoby\n" +
                "-\tObrázek(zdroj): Music-mordent.svg od autora: Denelson83, Jaksmata a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-mordent.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno\n" +
                "\n" +
                "Trylek\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/melodické-ozdoby\n" +
                "-\tObrázek(zdroj): Music-trill.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-trill.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno\n" +
                "\n" +
                "Obal\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/melodické-ozdoby\n" +
                "-\tObrázek(zdroj): Music-turn-2.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-turn-2.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – kombinace s dalším obrázkem + Music-turn (inverted).png od autora: Artlejandra, získáno z: https://en.wikipedia.org/wiki/File:Music-turn_(inverted).png, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno –  kombinace s dalším obrázkem\n" +
                "\n" +
                "Opora\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Seznam_hudebních_symbolů + https://www.muzikopedie.cz/teorie/základy-hudební-teorie/melodické-ozdoby\n" +
                "-\tObrázek(zdroj): Music-appoggiatura.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-appoggiatura.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – zakroužkování části obrázku \n" +
                "\n" +
                "Příraz\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/melodické-ozdoby\n" +
                "-\tObrázek(zdroj): https://en.wikipedia.org/wiki/File:Music-acciaccatura.svg (veřejná doména)\n" +
                "\n" +
                "Trámec\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Seznam_hudebních_symbolů\n" +
                "-\tObrázek(zdroj): Music-beam.svg od autora: DustyComputer, získáno z: https://en.wikipedia.org/wiki/File:Music-beam.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – zakroužkování části obrázku\n" +
                "\n" +
                "Taktový symbol o tvaru C\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Seznam_hudebních_symbolů\n" +
                "-\tObrázek(zdroj): Music-commontime.svg od autora: Denelson83 a Ekips39, získáno z: https://en.wikipedia.org/wiki/File:Music-commontime.svg, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, neupraveno\n" +
                "\n");

        pages.add("Crescendo\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/dynamika + https://cs.wikipedia.org/wiki/Seznam_hudebních_symbolů\n" +
                "-\tObrázek(zdroj): https://commons.wikimedia.org/wiki/File:Dynamik.png (veřejná doména) + Vaderjacob-Zanaq.png od autora: Zanaq, získáno z: https://commons.wikimedia.org/wiki/File:Vaderjacob-Zanaq.png, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – oříznutí a kombinace s jiným obrázkem \n" +
                "\n" +
                "Decrescendo\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/dynamika + https://cs.wikipedia.org/wiki/Seznam_hudebních_symbolů\n" +
                "-\tObrázek(zdroj):  https://commons.wikimedia.org/wiki/File:Dynamik.png (veřejná doména) + Vaderjacob-Zanaq.png od autora: Zanaq, získáno z: https://commons.wikimedia.org/wiki/File:Vaderjacob-Zanaq.png, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – oříznutí a kombinace s jiným obrázkem \n" +
                "\n" +
                "Zvuk\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Zvuk\n" +
                "Tón\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Tón\n" +
                "Rytmus\n" +
                "-\tDefinice(zdroj): https://kytaristka.cz/slovnik/rytmus\n" +
                "Metrum\n" +
                "-\tDefinice(zdroj): https://www.casopismuzikus.cz/clanky/zaklady-z-hudebni-nauky-v-otazkach-odpovedich-4-rytmika-metrika-1-cast\n" +
                "Diatonická stupnice\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/stupnice-základy\n" +
                "Stupnice\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Stupnice_(hudba)\n" +
                "Chromatická stupnice\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Chromatická_stupnice\n" +
                "Interval\n" +
                "-\tDefinice(zdroj): https://www.zussemily.cz/images/ke_stazeni/ZAKLADNI_POJMY.pdf\n" +
                "Akord\n" +
                "-\tDefinice(zdroj): https://www.zussemily.cz/images/ke_stazeni/ZAKLADNI_POJMY.pdf\n" +
                "Tónina\n" +
                "-\tDefinice(zdroj): https://www.zussemily.cz/images/ke_stazeni/ZAKLADNI_POJMY.pdf + https://webhouse.cz/kurz-harmonie/stupnice.htm\n" +
                "Enharmonická Záměna\n" +
                "-\tDefinice(zdroj): https://www.zuschvalenickaplzen.cz/file.php?nid=3434&oid=1906498\n" +
                "Předznamenání\n" +
                "-\tDefinice(zdroj): https://www.muzikopedie.cz/teorie/základy-hudební-teorie/stupnice-základy\n" +
                "Tritón\n" +
                "-\tDefinice(zdroj): https://cs.wikipedia.org/wiki/Tritón\n" +
                "Houslový klíč: \n" +
                "-\thttps://commons.wikimedia.org/wiki/File:Lilypond_Clef-G.svg (veřejná doména)\n");

        pages.add("Basový klíč: \n" +
                "-\thttps://commons.wikimedia.org/wiki/File:Bass_Clef_(34502)_-_The_Noun_Project.svg (veřejná doména)\n" +
                "Posuvky: \n" +
                "-\thttps://commons.wikimedia.org/wiki/File:Accidentals-piano_keyboard.svg (veřejná doména)\n" +
                "\nFont pro posuvky byl vytvořen pomocí: https://www.calligraphr.com\n" +
                "\n" +
                "Celá nota a pomlka: \n" +
                "-\tNota: https://commons.wikimedia.org/wiki/File:A_C_D_notes.svg (veřejná doména) – obrázek použit jako podklad\n" +
                "-\tPomlka: Music-wholerest.png od autora: Denelson83, získáno z: https://commons.wikimedia.org/wiki/File:Music-wholerest.png, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – oříznutí \n" +
                "\n" +
                "Půlová nota a pomlka: \n" +
                "-\tNota: https://commons.wikimedia.org/wiki/File:Figure_rythmique_equivalence_blanche_pointee.svg (veřejná doména)\n" +
                "-\tPomlka: Music-halfrest.png od autora: Denelson83, získáno z: https://commons.wikimedia.org/wiki/File:Music-halfrest.png, podle licence: https://creativecommons.org/licenses/by-sa/3.0/, upraveno – oříznutí \n" +
                "\n" +
                "Čtvrťová nota a pomlka: \n" +
                "-\tNota: 8thNote.svg od autora: PianistHere, získáno z: https://en.wikipedia.org/wiki/File:8thNote.svg, podle licence: https://creativecommons.org/licenses/by-sa/4.0/, upraveno – předěláno na čtvrťovou notu\n" +
                "-\tPomlky: https://en.wikipedia.org/wiki/File:Crotchet_rest_alt_plain-svg.svg (veřejná doména) + https://en.wikipedia.org/wiki/File:Crotchet_rest_plain-svg.svg (veřejná doména)\n" +
                "\n" +
                "Osminová nota a pomlka: \n" +
                "-\tNota: 8thNote.svg od autora: PianistHere, získáno z: https://en.wikipedia.org/wiki/File:8thNote.svg, podle licence: https://creativecommons.org/licenses/by-sa/4.0/, neupraveno \n" +
                "-\tPomlka: Eighth rest.svg od autora: Marmelad, získáno z: https://en.wikipedia.org/wiki/File:Eighth_rest.svg, podle licence: https://creativecommons.org/licenses/by-sa/2.5/, neupraveno\n" +
                "\n" +
                "Šestnáctinová nota a pomlka: \n" +
                "-\tNota: Sixteenth note with upwards stem.svg od autora: PianistHere, získáno z: https://commons.wikimedia.org/wiki/File:Sixteenth_note_with_upwards_stem.svg, podle licence: https://creativecommons.org/licenses/by-sa/4.0/, neupraveno\n");

        credits1.setText(pages.get(currentPage));
        hideButtons();
    }

    public void backToTheMenu (MouseEvent mouseEvent) throws Exception {
        Parent parent = FXMLLoader.load(getClass().getResource("/sample/exerciseSelectionMenu.fxml"));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) back.getScene().getWindow();
        defaultScene.setScene(scene);
    }

    private void hideButtons()
    {
        if(currentPage == pages.size()-1)
        {
            nextPage.setVisible(false);
        }
        else
        {
            nextPage.setVisible(true);
        }

        if(currentPage == 0)
        {
            previousPage.setVisible(false);
        }
        else
        {
            previousPage.setVisible(true);
        }
    }


    public void nextPageClick(MouseEvent mouseEvent) {
        if(!(currentPage == pages.size()-1))
        {
            currentPage++;
            credits1.setText(pages.get(currentPage));
            hideButtons();
        }
    }

    public void previousPageClick(MouseEvent mouseEvent) {
        if(!(currentPage == 0))
        {
            currentPage--;
            credits1.setText(pages.get(currentPage));
            hideButtons();
        }
    }
}
