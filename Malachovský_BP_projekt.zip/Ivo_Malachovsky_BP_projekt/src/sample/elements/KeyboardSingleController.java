package sample.elements;

import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class KeyboardSingleController {

    public Rectangle cKey, dKey, eKey, fKey, gKey, aKey, hKey;
    public Rectangle csKey, dsKey, fsKey, gsKey, asKey;

    private String providedAnswer = "";
    private String selectedKey = "#B0FEB5";

    public void onCKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        wKeyChange(cKey);
        providedAnswer = "C?";
    }
    public void onDKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        wKeyChange(dKey);
        providedAnswer = "D?";
    }
    public void onEKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        wKeyChange(eKey);
        providedAnswer = "E?";
    }
    public void onFKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        wKeyChange(fKey);
        providedAnswer = "F?";
    }
    public void onGKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        wKeyChange(gKey);
        providedAnswer = "G?";
    }
    public void onAKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        wKeyChange(aKey);
        providedAnswer = "A?";
    }
    public void onHKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        wKeyChange(hKey);
        providedAnswer = "H?";
    }
    public void onCsKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        bKeyChange(csKey);
        providedAnswer = "C?#";
    }
    public void onDsKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        bKeyChange(dsKey);
        providedAnswer = "D?#";
    }
    public void onFsKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        bKeyChange(fsKey);
        providedAnswer = "F?#";
    }
    public void onGsKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        bKeyChange(gsKey);
        providedAnswer = "G?#";
    }
    public void onAsKeyClickEvent(MouseEvent mouseEvent) {
        deactivateWholeKeyboard();
        bKeyChange(asKey);
        providedAnswer = "A?#";
    }

    private void deactivateWholeKeyboard() {
        cKey.setFill(Color.web("0xffffffff"));
        dKey.setFill(Color.web("0xffffffff"));
        eKey.setFill(Color.web("0xffffffff"));
        fKey.setFill(Color.web("0xffffffff"));
        gKey.setFill(Color.web("0xffffffff"));
        aKey.setFill(Color.web("0xffffffff"));
        hKey.setFill(Color.web("0xffffffff"));
        csKey.setFill(Color.web("0x000000ff"));
        dsKey.setFill(Color.web("0x000000ff"));
        fsKey.setFill(Color.web("0x000000ff"));
        gsKey.setFill(Color.web("0x000000ff"));
        asKey.setFill(Color.web("0x000000ff"));
    }

    public void wKeyChange(Rectangle rectangle)
    {

        if(rectangle.getFill().toString().equals("0xffffffff"))
        {
            rectangle.setFill(Color.web(selectedKey));
        }
        else
        {
            rectangle.setFill(Color.web("0xffffffff"));
        }
    }

    public void bKeyChange(Rectangle rectangle)
    {
        if(rectangle.getFill().toString().equals("0x000000ff"))
        {
            rectangle.setFill(Color.web(selectedKey));
        }
        else
        {
            rectangle.setFill(Color.web("0x000000ff"));
        }
    }

    public String getProvidedAnswer() {
        return providedAnswer;
    }
}
