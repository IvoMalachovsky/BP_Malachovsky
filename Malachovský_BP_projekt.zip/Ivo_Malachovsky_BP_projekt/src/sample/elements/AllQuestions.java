package sample.elements;

import java.util.ArrayList;

public class AllQuestions {
    private ArrayList<QuestionQuiz> questionsList = new ArrayList<QuestionQuiz>();

    public AllQuestions() {
        questionsList.add(new QuestionQuiz("Tečka","Tento symbol prodlužuje notu o polovinu její původní délky",1));
        questionsList.add(new QuestionQuiz("Ligatura","Tento symbol spojuje jednu nebo více stejně vysokých not v jednu",2));
        questionsList.add(new QuestionQuiz("Staccato","Symbol u noty označující, že se daná nota má zahrát krátce",3));
        questionsList.add(new QuestionQuiz("Pomlka","Symbol, který určuje místo, kde se nic nehraje. Svým tvarem určuje svoji délku",4));
        questionsList.add(new QuestionQuiz("Forte","Symbol, psaný pod osnovou označující, že dané noty mají být zahrány silně",5));
        questionsList.add(new QuestionQuiz("Taktové označení","Označení, určující délku jednoho krátkého časového úseku hudební skladby, kde se střídají přízvučné (noty) a nepřízvučné (pomlky) stejně dlouhé doby",6));
        questionsList.add(new QuestionQuiz("C klíč","Klíč, jehož referenční tón c1 na třetí lince",7));
        questionsList.add(new QuestionQuiz("Legato","Symbol znamenající, že dané noty mají být hrány vázaně",8));
        questionsList.add(new QuestionQuiz("Koruna","Tento symbol určuje, že daná nota má být hrána o libovolnou délku déle, než je její zapsaná délka",9));
        questionsList.add(new QuestionQuiz("Repetice","Označení pro část skladby, kterou opakujeme",10));
        questionsList.add(new QuestionQuiz("Akcent","Tento symbol označuje danou notu v taktu, kterou zvýrazňujeme",11));
        questionsList.add(new QuestionQuiz("Piano","Symbol, psaný pod osnovou označující, že dané noty mají být zahrány slabě",12));
        questionsList.add(new QuestionQuiz("Triola","skupina tří stejně dlouhých not hraných v době jinak určené pro dvě noty",13));
        questionsList.add(new QuestionQuiz("Da capo al fine","Opakování skladby od začátku po značku Fine",14));
        questionsList.add(new QuestionQuiz("Primavolta a sekundavolta","Označení části skladby, která je při opakování vynechána a nahrazena druhou částí",15));
        questionsList.add(new QuestionQuiz("Tenuto","Symbol znamenající, že dané noty zřetelně oddělujeme, ale zároveň je nezkracujeme",16));
        questionsList.add(new QuestionQuiz("Zvýraznění","Tento symbol označuje danou notu v taktu, kterou zhlasiťujeme",17));
        questionsList.add(new QuestionQuiz("Glissando","Označení pro skluz z jedné noty na druhou, hráč se musí po jednotlivých tónech dostat z jedné noty na druhou",18));
        questionsList.add(new QuestionQuiz("Arpeggio","Označení určující, že daný akord se má zahrát postupně tón po tónu",19));
        questionsList.add(new QuestionQuiz("Tremolo","Označení pro rychlé střídání not. Lze střídat danou notu za tu samou notu nebo za druhou notu",20));
        questionsList.add(new QuestionQuiz("Nátryl","Technika, kdy se zahraje zapsaný tón, následně (diatonický) tón nad ním a znovu zapsaný tón",21));
        questionsList.add(new QuestionQuiz("Trylek","Rychlé střídaní mezi zapsaným tónem a (diatonickým) tónem nad ním po dobu trvání noty",22));
        questionsList.add(new QuestionQuiz("Obal","Technika, kdy se zahraje tón nad zapsaným tónem, následně zapsaný tón, následně tón pod zapsaným tónem a nakonec znovu zapsaný tón. Existuje i verze kdy je postup v opačném pořadí",23));
        questionsList.add(new QuestionQuiz("Opora","Malá nota před hlavní notou, která ubírá polovinu trvání z hlavní noty a klade se na ni důraz. Malá nota musí být vždy o polovinu kratší než hlavní nota.",24));
        questionsList.add(new QuestionQuiz("Příraz","Malá nota před hlavní notou, která označuje krátký tón před hlavním tónem. Důraz se klade na hlavní tón.",25));
        questionsList.add(new QuestionQuiz("Trámec","Slouží ke grafickému spojení not osminových a nižších. Jejich počet odpovídá počtu praporků u noty",26));
        questionsList.add(new QuestionQuiz("Taktový symbol o tvaru C","Alternativní značka pro 4/4 takt",27));
        questionsList.add(new QuestionQuiz("Crescendo","Symbol, psaný pod notovou linkou, znázorňující postupné zesilování. Je možné za něj uvést značku hlasitosti, určující k jaké hlasitosti se má zesilováním dojít.",28));
        questionsList.add(new QuestionQuiz("Decrescendo","Symbol, psaný pod notovou linkou, znázorňující postupné zeslabování. Je možné za něj uvést značku hlasitosti, určující k jaké hlasitosti se má zeslabováním dojít.",29));
        questionsList.add(new QuestionQuiz("Zvuk","Mechanické vlnění v látkovém prostředí"));
        questionsList.add(new QuestionQuiz("Tón","Zvuk s periodickým průběhem kmitů"));
        questionsList.add(new QuestionQuiz("Rytmus","Střídání dlouhých a krátkých tónů"));
        questionsList.add(new QuestionQuiz("Metrum","Střídání přízvučných a nepřízvučných dob"));
        questionsList.add(new QuestionQuiz("Diatonická stupnice","Stupnice tvořena sedmi tóny, mezi nimiž může být interval o vzdálenosti celého tónu nebo půltónu"));
        questionsList.add(new QuestionQuiz("Stupnice","Řada tónů uspořádaná podle určitých pravidel"));
        questionsList.add(new QuestionQuiz("Chromatická stupnice","Stupnice tvořena dvanácti tóny, mezi nimiž je interval o vzdálenosti půltónu"));
        questionsList.add(new QuestionQuiz("Interval","Vzdálenost mezi dvěma tóny"));
        questionsList.add(new QuestionQuiz("Akord","Souzvuk nejméně tří tónů"));
        questionsList.add(new QuestionQuiz("Tónina","Soubor všech tónů z dané stupnice"));
        questionsList.add(new QuestionQuiz("Enharmonická Záměna","Záměna daného tónu za tón stejné výšky, ale jiného jména."));
        questionsList.add(new QuestionQuiz("Předznamenání","Napsání posuvek (křížky, béčka...) na začátek notové osnovy. Tyto posuvky pak platí po celou skladbu" ));
        questionsList.add(new QuestionQuiz("Tritón","Hudební interval obsahující tři celé tóny. Dá se nazvat také jako zvětšená kvarta nebo zmenšená kvinta"));
    }

    public ArrayList<QuestionQuiz> getQuestionsList() {
        return questionsList;
    }
}




