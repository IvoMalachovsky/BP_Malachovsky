package sample.elements;

import java.util.ArrayList;
import java.util.Random;

public class QuizQuestionGenerator {
    private ArrayList<QuestionQuiz> questions;
    private ArrayList<QuestionQuiz> tempQuestions;

    private String lastSelectedSymbol="";

    public QuizQuestionGenerator(ArrayList<QuestionQuiz> questions)
    {
        this.questions = questions;
    }

    public ArrayList<QuestionQuiz> generateQuestions(int numberOfQuestions) {
        tempQuestions = new ArrayList<QuestionQuiz>(questions);

        ArrayList<QuestionQuiz> questions = new ArrayList<QuestionQuiz>();

        for (int i = 0; i<numberOfQuestions; i++)
        {
            questions.add(generateQuestion());
        }

        return questions;
    }

    public ArrayList<String> getAnswers() {
        ArrayList<String> temp = new ArrayList<String>();
        for(int i = 0; i < questions.size(); i++)
        {
            temp.add(questions.get(i).getName());
        }

        return temp;
    }

    private QuestionQuiz generateQuestion() {
        Random rnd = new Random();
        QuestionQuiz question;

        if (tempQuestions.size() <= 0) {
            tempQuestions = new ArrayList<QuestionQuiz>(questions);
        }

        int randomQuestion = rnd.nextInt(tempQuestions.size());

        if(lastSelectedSymbol.equals(tempQuestions.get(randomQuestion).getName()) && tempQuestions.size()>1)
        {
            tempQuestions.remove(randomQuestion);
            randomQuestion = rnd.nextInt(tempQuestions.size());
        }

        question = tempQuestions.get(randomQuestion);
        lastSelectedSymbol = question.getName();
        tempQuestions.remove(randomQuestion);

        return question;
    }

    public ArrayList<Integer> getAvailableQuestions()
    {
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        for(int i = 0; i<questions.size(); i++)
        {
            numbers.add(questions.get(i).getImageId());
        }

        return numbers;
    }
}
