package sample.elements;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import sample.logic.AllNotes;
import sample.logic.KeyboardLogic;
import sample.logic.NoteOperations;

import java.util.ArrayList;

public class KeyboardDoubleController {
    public Rectangle C1, D1, E1, F1, G1, A1, H1;
    public Rectangle C2, D2, E2, F2, G2, A2, H2;
    public Rectangle C1s, D1s, F1s, G1s, A1s;
    public Rectangle C2s, D2s, F2s, G2s, A2s;

    @FXML private KeyboardLogic keyboardLogic = new KeyboardLogic();
    private boolean activeKeyboard = true;

    public void initialize() {
        keyboardLogic.initializeActiveKeys();
    }


    public void onC1KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){ keyboardLogic.wKeyChange(C1);}
    }

    public void onD1KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(D1);}
    }

    public void onE1KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(E1);}
    }

    public void onF1KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(F1);}
    }

    public void onG1KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(G1);}
    }

    public void onA1KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(A1);}
    }

    public void onH1KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(H1);}
    }

    public void onC2KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(C2);}
    }

    public void onD2KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(D2);}
    }

    public void onE2KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(E2);}
    }

    public void onF2KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(F2);}
    }

    public void onG2KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(G2);}
    }

    public void onA2KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(A2);}
    }

    public void onH2KeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.wKeyChange(H2);}
    }

    public void onC1sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(C1s);}
    }

    public void onD1sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(D1s);}
    }

    public void onF1sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(F1s);}
    }

    public void onG1sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(G1s);}
    }

    public void onA1sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(A1s);}
    }

    public void onC2sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(C2s);}
    }

    public void onD2sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(D2s);}
    }

    public void onF2sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(F2s);}
    }

    public void onG2sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(G2s);}
    }

    public void onA2sKeyClickEvent(MouseEvent mouseEvent) {
        if(activeKeyboard){keyboardLogic.bKeyChange(A2s);}
    }

    @FXML public boolean checkAnswer(ArrayList<String> answer) {
        return keyboardLogic.checkTheCorrectAnswer(answer);
    }

    public void highlightKeys(ArrayList<String> keys)
    {
        NoteOperations nOp = new NoteOperations();
        AllNotes an = new AllNotes();

        String color = "#F6FF25";

        for(int i = 0; i<keys.size(); i++)
        {
            keys.set(i, nOp.normalizeNote(keys.get(i)));
        }

        for(String key: keys)
        {
            if(an.translateStringNote(key).getId() > 28)
            {
                keys = new ArrayList<String>(nOp.decreaseOctaveMultiple(keys));
                break;
            }
            if(an.translateStringNote(key).getId() < 5)
            {
                keys = new ArrayList<String>(nOp.increaseOctaveMultiple(keys));
                break;
            }
        }

        deactivateWholeKeyboard();

        if(keys.contains("C1")){C1.setFill(Color.web(color));}
        if(keys.contains("D1")){D1.setFill(Color.web(color));}
        if(keys.contains("E1")){E1.setFill(Color.web(color));}
        if(keys.contains("F1")){F1.setFill(Color.web(color));}
        if(keys.contains("G1")){G1.setFill(Color.web(color));}
        if(keys.contains("A1")){A1.setFill(Color.web(color));}
        if(keys.contains("H1")){H1.setFill(Color.web(color));}
        if(keys.contains("C1#")){C1s.setFill(Color.web(color));}
        if(keys.contains("D1#")){D1s.setFill(Color.web(color));}
        if(keys.contains("F1#")){F1s.setFill(Color.web(color));}
        if(keys.contains("G1#")){G1s.setFill(Color.web(color));}
        if(keys.contains("A1#")){A1s.setFill(Color.web(color));}

        if(keys.contains("C2")){C2.setFill(Color.web(color));}
        if(keys.contains("D2")){D2.setFill(Color.web(color));}
        if(keys.contains("E2")){E2.setFill(Color.web(color));}
        if(keys.contains("F2")){F2.setFill(Color.web(color));}
        if(keys.contains("G2")){G2.setFill(Color.web(color));}
        if(keys.contains("A2")){A2.setFill(Color.web(color));}
        if(keys.contains("H2")){H2.setFill(Color.web(color));}
        if(keys.contains("C2#")){C2s.setFill(Color.web(color));}
        if(keys.contains("D2#")){D2s.setFill(Color.web(color));}
        if(keys.contains("F2#")){F2s.setFill(Color.web(color));}
        if(keys.contains("G2#")){G2s.setFill(Color.web(color));}
        if(keys.contains("A2#")){A2s.setFill(Color.web(color));}
    }

    private void deactivateWholeKeyboard() {
        C1.setFill(Color.web("0xffffffff"));
        D1.setFill(Color.web("0xffffffff"));
        E1.setFill(Color.web("0xffffffff"));
        F1.setFill(Color.web("0xffffffff"));
        G1.setFill(Color.web("0xffffffff"));
        A1.setFill(Color.web("0xffffffff"));
        H1.setFill(Color.web("0xffffffff"));

        C2.setFill(Color.web("0xffffffff"));
        D2.setFill(Color.web("0xffffffff"));
        E2.setFill(Color.web("0xffffffff"));
        F2.setFill(Color.web("0xffffffff"));
        G2.setFill(Color.web("0xffffffff"));
        A2.setFill(Color.web("0xffffffff"));
        H2.setFill(Color.web("0xffffffff"));

        C1s.setFill(Color.web("0x000000ff"));
        D1s.setFill(Color.web("0x000000ff"));
        F1s.setFill(Color.web("0x000000ff"));
        G1s.setFill(Color.web("0x000000ff"));
        A1s.setFill(Color.web("0x000000ff"));

        C2s.setFill(Color.web("0x000000ff"));
        D2s.setFill(Color.web("0x000000ff"));
        F2s.setFill(Color.web("0x000000ff"));
        G2s.setFill(Color.web("0x000000ff"));
        A2s.setFill(Color.web("0x000000ff"));
    }

    public void setActiveKeyboard(boolean activeKeyboard) {
        this.activeKeyboard = activeKeyboard;
    }
}