package sample.elements;

import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import sample.logic.FullNotes;

import java.util.ArrayList;

public class StaffController {
    private ArrayList<String> answer;
    private ArrayList<String> activeNotes = new ArrayList<String>();

    public Line eLine, gLine, hLine, dLine, fLine;
    public ImageView note1, note2, note3, note4, note5, note6, note7, note8;
    public Label p1, p2, p3, p4, p5, p6, p7, p8;
    public Label q1, q2, q3, q4, q5, q6, q7;
    public ImageView bClef, tClef;

    public Line lineL11, lineL21, lineL31, lineL41, lineL51, lineL61, lineL71, lineL81, lineU11, lineU21, lineU31, lineU41, lineU51, lineU61, lineU71, lineU81;
    public Line lineL12, lineL22, lineL32, lineL42, lineL52, lineL62, lineL72, lineL82, lineU12, lineU22, lineU32, lineU42, lineU52, lineU62, lineU72, lineU82;
    public Line lineL13, lineL23, lineL33, lineL43, lineL53, lineL63, lineL73, lineL83, lineU13, lineU23, lineU33, lineU43, lineU53, lineU63, lineU73, lineU83;

    double shift;

    public void start(ArrayList<String> answer, boolean dual, boolean bass)
    {
        this.answer = answer;
        if(dual)
        {
            shift=23;
        }
        else {shift = 32;}

        displayScale();
        setQsB();
        if(bass) {
            switchToBassKey();
        }
        disableUnactiveNotes();
        linesLogicGeneral();

        Font font = Font.loadFont("file:src/sample/elements/assets/NotesFont.ttf", 83);
        if(dual) {
            font = Font.loadFont("file:src/sample/elements/assets/NotesFont.ttf", 62);
        }
        p1.setFont(font);
        p2.setFont(font);
        p3.setFont(font);
        p4.setFont(font);
        p5.setFont(font);
        p6.setFont(font);
        p7.setFont(font);
        p8.setFont(font);

        q1.setFont(font);
        q2.setFont(font);
        q3.setFont(font);
        q4.setFont(font);
        q5.setFont(font);
        q6.setFont(font);
        q7.setFont(font);
    }

    public void start(ArrayList<String> answer, boolean dual, boolean bass, String name)
    {
        start(answer,dual, bass);
        for (int i = 0; i<answer.size(); i++)
        {
            if(name.substring(0,1).equals(answer.get(i).substring(0,1)))
            {
                Object imageObject = null;
                ImageView note=null;

                int tempI = i + 1;

                try{ imageObject = getClass().getDeclaredField("note"+tempI).get(this);}
                catch (Exception e){
                    System.out.println("note not found");
                }
                note = (ImageView) imageObject;
                Image image = new Image(getClass().getResourceAsStream("/sample/elements/assets/noteRoot.png"));
                note.setImage(image);
            }
        }
    }

    public void switchToBassKey()
    {
        Object imageObject = null;
        Object labelPObject = null;
        Object labelQObject = null;
        ImageView note=null;
        Label labelP=null;
        Label labelQ=null;

        tClef.setVisible(false);
        bClef.setVisible(true);

        for (int i = 1; i<=8; i++)
        {
            try{ imageObject = getClass().getDeclaredField("note"+i).get(this);}
            catch (Exception e){
                System.out.println("note not found");
            }
            note = (ImageView) imageObject;
            note.setLayoutY(note.getLayoutY()+shift);

            if(i!=8) {
                try {
                    labelQObject = getClass().getDeclaredField("q" + i).get(this);
                } catch (Exception e) {
                    System.out.println("q not found");
                }
                labelQ = (Label) labelQObject;
                labelQ.setLayoutY(labelQ.getLayoutY() + shift);
                labelQ.setLayoutX(labelQ.getLayoutX() + 7);
            }
            try{ labelPObject = getClass().getDeclaredField("p"+i).get(this);}
            catch (Exception e){
                System.out.println("p not found");
            }
            labelP = (Label) labelPObject;
            labelP.setLayoutY(labelP.getLayoutY()+shift);
        }
    }

    private double calculateShift(String note)
    {
        FullNotes fn = new FullNotes();
        return -((shift/2)*fn.findIdOfAFullNote(note));
    }

    public void displayScale ()
    {
        Object note=null;
        Object p = null;

        Label pLabel;

        for (int index = 0; index<answer.size(); index++) {
            try {
                note = getClass().getDeclaredField("note" + (index + 1)).get(this);
                p = getClass().getDeclaredField("p" + (index + 1)).get(this);
            } catch (Exception e) {
                System.out.println("error at displayScale -> note not found");
            }

            activeNotes.add("note" + (index+1));
            setNoteUp((ImageView) note,(Label) p, index);
            pLabel = (Label) p;
            pLabel.setVisible(visibleP(index));
            pLabel.setText(setPLabel(answer.get(index)));
            if(pLabel.getText().equals("C"))
            {
                pLabel.setLayoutX(pLabel.getLayoutX()-4);
            }
            if(pLabel.getText().equals("E"))
            {
                pLabel.setLayoutX(pLabel.getLayoutX()-20);
            }
            if(pLabel.getText().equals("F"))
            {
                pLabel.setLayoutX(pLabel.getLayoutX()-40);
            }
            if(pLabel.getText().equals("G"))
            {
                pLabel.setLayoutX(pLabel.getLayoutX()-45);
            }
        }

    }

    public void disableUnactiveNotes()
    {
        Object note=null;
        Object p = null;

        ImageView noteImage;
        Label pLabel;

        for (int index = 0; index<=7; index++) {
            try {
                note = getClass().getDeclaredField("note" + (index + 1)).get(this);
                p = getClass().getDeclaredField("p" + (index + 1)).get(this);
            } catch (Exception e) {
                System.out.println("error at displayScale -> note not found");
            }

            noteImage = (ImageView) note;
            pLabel = (Label) p;

            if(!(activeNotes.contains("note" + (index + 1))))
            {
                noteImage.setLayoutY(164);
                noteImage.setVisible(false);
                pLabel.setVisible(false);
            }

        }
    }

    public String setPLabel(String note)
    {
        StringBuilder signs = new StringBuilder();
        int signIndex = 0;

        for(int i = 0; i<note.length(); i++)
        {
            if(note.charAt(i) == '#' || note.charAt(i) == 'b' || note.charAt(i) == 's' || note.charAt(i) == 'f')
            {
                signs.append(note.charAt(i));
            }
        }

        if(!(signs.toString().contains("#")) && !(signs.toString().contains("b")))
        {
            return "";
        }
        else
        {
            for(int i = 0; i<note.length(); i++)
            {
                if(note.charAt(i) == 's' || note.charAt(i) == '#')
                {
                    signIndex++;
                }
                else if(note.charAt(i) == 'f' || note.charAt(i) == 'b')
                {
                    signIndex--;
                }
            }

            if (signIndex == 0)
            {
                return "D";
            }
            else if (signIndex == 1)
            {
                return "A";
            }
            else if (signIndex == 2)
            {
                return "C";
            }
            else if (signIndex == -1)
            {
                return "B";
            }
            else if (signIndex == -2)
            {
                return "E";
            }
            else if (signIndex == 3)
            {
                return "F";
            }
            else if (signIndex == -3)
            {
                return "G";
            }

        }


        return signs.toString();
    }

    public void setNoteUp(ImageView note, Label p , int index)
    {
        double shift = calculateShift(answer.get(index));
        note.setLayoutY(note.getLayoutY()+shift);
        p.setLayoutY(p.getLayoutY()+shift);
    }

    public void setNoteDown(ImageView note, Label p, int index)
    {
        double shift = calculateShift(answer.get(index));
        note.setLayoutY(note.getLayoutY()+shift);
        p.setLayoutY(p.getLayoutY()+shift);
    }

    public boolean visibleP(int index)
    {
        if(answer.get(index).contains("#") || answer.get(index).contains("b") )
        {
            return true;
        }
        else
        {
            return false;
        }


    }


    public void setQsB()
    {
        String[] sharps = {"F2s", "C2s", "G2s", "D2s", "A1s", "E2s", "H1s"};
        String[] flats = {"H1f", "E2f", "A1f", "D2f", "G1f", "C2f", "F1f"};

        ArrayList<String> sharpsScale = getSigns('s');
        ArrayList<String> flatsScale = getSigns('f');

        if(sharpsScale.size() > 0)
        {
            setSignsRename(sharpsScale, sharps);
        }
        if(flatsScale.size() > 0) {
            setSignsToFlat();
            setSignsRename(flatsScale, flats);
        }

        if(sharpsScale.size() == 0 && flatsScale.size()==0)
        {
            setAllQsToInvisible();
        }


    }
    private void setAllQsToInvisible()
    {
        Label qLabel=new Label();
        Object q=null;

        for (int i = 0; i < 7; i++)
        {
            try{q = getClass().getDeclaredField("q"+(i+1)).get(this);}
            catch (Exception e){System.out.println("Error at q - setAllQsToInvisible");}
            if(q != null) {
                qLabel = (Label) q;
            }

            qLabel.setVisible(false);
        }
    }


    private void setSignsToFlat()
    {
        Label qLabel=new Label();
        Object q=null;

        for (int i = 0; i < 7; i++)
        {
            try{q = getClass().getDeclaredField("q"+(i+1)).get(this);}
            catch (Exception e){System.out.println("Error at q - signsToFlat");}
            if(q != null) {
                qLabel = (Label) q;
            }

            qLabel.setText("B");
        }
    }

    private void setSignsRename(ArrayList<String> signsScale, String[] signs)
    {
        Label qLabel=new Label();
        Object q=null;

        boolean visible = false;

        for(int i = 0; i<signs.length; i++)
        {
            try{q = getClass().getDeclaredField("q"+(i+1)).get(this);}
            catch (Exception e){System.out.println("Error at q - SignsRename");}
            if(q != null) {
                qLabel = (Label) q;
            }


            for (String signScale: signsScale)
            {
                if((signs[i].substring(0,1)+signs[i].charAt(2)).equals((signScale.substring(0,1)+signScale.charAt(2))))
                {
                    qLabel.setLayoutY(qLabel.getLayoutY() + calculateShift(signs[i]));
                    if(signScale.contains("ss"))
                    {
                        qLabel.setText("C");
                    }
                    if(signScale.contains("ff"))
                    {
                        qLabel.setText("E");
                    }
                    visible = true;
                }
            }
            qLabel.setVisible(visible);
            visible = false;
        }
    }


    private ArrayList<String> getSigns(char sign)
    {
        ArrayList<String> temp = new ArrayList<String>();

        for (int i = 0; i < answer.size() - 1; i++) {
            if (answer.get(i).length() > 2) {
                if (answer.get(i).charAt(2) == sign) {
                    temp.add(answer.get(i));
                }
            }
        }

        return temp;

    }


    public void linesLogicGeneral()
    {
        Object lineGeneral = null;
        Object noteGeneral = null;
        Line lineTemp = null;
        ImageView tempNote = null;

        for(int j = 1; j<=8; j++) {
            try {
                noteGeneral = getClass().getDeclaredField("note"+j).get(this);
            } catch (Exception e) {
                System.out.println("Error at note");
            }
            tempNote = (ImageView) noteGeneral;


            for (int i = 1; i <= 3; i++) {
                try {
                    lineGeneral = getClass().getDeclaredField("lineL"+j+""+ i).get(this);
                } catch (Exception e) {
                    System.out.println("Error at line");
                }
                lineTemp = (Line) lineGeneral;

                if ((tempNote.getLayoutY() + (shift/2)) < lineTemp.getLayoutY()) {
                    lineTemp.setVisible(false);
                }
            }

            for (int i = 1; i <= 3; i++) {
                try {
                    lineGeneral = getClass().getDeclaredField("lineU"+j+""+ i).get(this);
                } catch (Exception e) {
                    System.out.println("Error at line");
                }
                lineTemp = (Line) lineGeneral;

                if ((tempNote.getLayoutY() + (shift/2)) > lineTemp.getLayoutY()) {
                    lineTemp.setVisible(false);
                }
            }
        }

    }

    public String adjustAccidentals(String accidental)
    {
        if(accidental.equals("#"))
        {
            return "s";
        }
        else if(accidental.equals("b"))
        {
            return "f";
        }
        else
        {
            return "";
        }
    }

    public String adjustAnswerName(String answerName)
    {
        String toReturn = "";
        if(answerName.length() > 2)
        {
            toReturn = toReturn + answerName.charAt(0) + answerName.substring(2);
        }
        else
        {
            toReturn = toReturn + answerName.charAt(0);
        }

        return toReturn;

    }

}
