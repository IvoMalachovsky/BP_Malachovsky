package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ExerciseSelectionMenu {

    public AnchorPane notesExcAccess, snkExcAccess, sbnExcAccess, ankExcAccess, abnExcAccess;
    public AnchorPane ibExcAccess, ilExcAccess, qnExcAccess, qtExcAccess, qsExcAccess, qcExcAccess;
    public Button exitButton, aboutButton;

    public void notesExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("NotesExercise/NotesExercise.fxml", notesExcAccess);
    }

    public void snkExcAccessClick(MouseEvent mouseEvent) throws Exception{
        loadScene("ScaleNameKey/ScaleNameKeyExercise.fxml", snkExcAccess);
    }

    public void sbnExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("ScaleBarName/ScaleBarNameExercise.fxml", sbnExcAccess);
    }

    public void ankExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("ChordNameKey/ChordNameKeyExercise.fxml", ankExcAccess);
    }

    public void abnExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("ChordStaffName/ChordStaffNameExercise.fxml", abnExcAccess);
    }

    public void qcExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("QuizCombined/QuizCombinedExercise.fxml", qcExcAccess);
    }

    public void ibExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("IntervalStaff/IntervalStaffExercise.fxml", ibExcAccess);
    }

    public void ilExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("IntervalListening/IntervalListeningExercise.fxml", ilExcAccess);
    }

    public void qnExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("QuizRythm/QuizRythmExercise.fxml", qnExcAccess);
    }

    public void qtExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("QuizTerminology/QuizTerminologyExercise.fxml", qtExcAccess);
    }

    public void qsExcAccessClick(MouseEvent mouseEvent) throws Exception {
        loadScene("QuizSymbols/QuizSymbolsExercise.fxml", qsExcAccess);
    }

    public void exitButtonClick(MouseEvent mouseEvent) throws Exception{
        Stage defaultScene = (Stage) exitButton.getScene().getWindow();
        defaultScene.close();
    }

    @FXML
    private void aboutButtonClick(MouseEvent mouseEvent) throws Exception{
        Parent parent = FXMLLoader.load(getClass().getResource("about.fxml"));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) aboutButton.getScene().getWindow();
        defaultScene.setScene(scene);
    }

    private void loadScene(String sceneName, AnchorPane pane) throws Exception
    {
        Parent parent = FXMLLoader.load(getClass().getResource("/sample/exercises/"+sceneName));
        Scene scene = new Scene(parent);
        Stage defaultScene = (Stage) pane.getScene().getWindow();
        defaultScene.setScene(scene);
    }
}
