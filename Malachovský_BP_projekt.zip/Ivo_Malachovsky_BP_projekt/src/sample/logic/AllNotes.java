package sample.logic;

import java.util.ArrayList;
import java.util.Arrays;

public class AllNotes {
    private ArrayList<Note> allNotes = new ArrayList<Note>();

    public AllNotes()
    {
        int id = 0;
        int i = 0;

        allNotes.add(new Note("G", i, id));
        id++;
        allNotes.add(new Note("G#", i, id));
        id++;
        allNotes.add(new Note("A", i, id));
        id++;
        allNotes.add(new Note("A#", i, id));
        id++;
        allNotes.add(new Note("H", i, id));
        id++;
        i++;
        allNotes.add(new Note("C", i, id));
        id++;
        allNotes.add(new Note("C#", i, id));
        id++;
        allNotes.add(new Note("D", i, id));
        id++;
        allNotes.add(new Note("D#", i, id));
        id++;
        allNotes.add(new Note("E", i, id));
        id++;
        allNotes.add(new Note("F", i, id));
        id++;
        allNotes.add(new Note("F#", i, id));
        id++;
        allNotes.add(new Note("G", i, id));
        id++;
        allNotes.add(new Note("G#", i, id));
        id++;
        allNotes.add(new Note("A", i, id));
        id++;
        allNotes.add(new Note("A#", i, id));
        id++;
        allNotes.add(new Note("H", i, id));
        id++;
        i++;
        allNotes.add(new Note("C", i, id));
        id++;
        allNotes.add(new Note("C#", i, id));
        id++;
        allNotes.add(new Note("D", i, id));
        id++;
        allNotes.add(new Note("D#", i, id));
        id++;
        allNotes.add(new Note("E", i, id));
        id++;
        allNotes.add(new Note("F", i, id));
        id++;
        allNotes.add(new Note("F#", i, id));
        id++;
        allNotes.add(new Note("G", i, id));
        id++;
        allNotes.add(new Note("G#", i, id));
        id++;
        allNotes.add(new Note("A", i, id));
        id++;
        allNotes.add(new Note("A#", i, id));
        id++;
        allNotes.add(new Note("H", i, id));
        id++;
        i++;
        allNotes.add(new Note("C", i, id));
        id++;
        allNotes.add(new Note("C#", i, id));
        id++;
        allNotes.add(new Note("D", i, id));
        id++;
        allNotes.add(new Note("D#", i, id));
        id++;
        allNotes.add(new Note("E", i, id));
        id++;
        allNotes.add(new Note("F", i, id));
        id++;
        allNotes.add(new Note("F#", i, id));
    }

    public void printAllNotes()
    {
        for(int i = 0; i<allNotes.size(); i++)
        {
            System.out.println(allNotes.get(i).getPrintableElements());
        }
    }

    public Note getNoteById(int id)
    {
        Note note = null;
        for(int i = 0; i<allNotes.size(); i++)
        {
            if(allNotes.get(i).getId() == id)
            {
                note = allNotes.get(i);
            }
        }
        return note;
    }

    public Note getNoteByNameAndOctave(String name, int octave) {
        for (int i = 0; i < allNotes.size(); i++)
        {
            if(name.equals(allNotes.get(i).getName()) && octave == allNotes.get(i).getOctave())
            {
                return allNotes.get(i);
            }
        }
        return null;
    }

    public Note translateStringNote(String stringNote)
    {
        Note tempNote;
        int tempId = 0;
        String shifts;

        tempNote = getNoteByNameAndOctave(stringNote.substring(0,1),Integer.parseInt(stringNote.substring(1,2)));
        tempId = tempNote.getId();
        shifts = stringNote.substring(2);

        for(int i = 0; i < shifts.length(); i++)
        {
            if(shifts.charAt(i) == '#' || shifts.charAt(i) == 's')
            {
                tempId++;
            }
            else if(shifts.charAt(i) == 'b' || shifts.charAt(i) == 'f')
            {
                tempId--;
            }
        }

        return getNoteById(tempId);
    }



    public boolean areNotesValidCheck(ArrayList<String> notes)
    {
        AllNotes allNotes = new AllNotes();

        for (String note: notes)
        {
            try{
                allNotes.translateStringNote(note);
            }
            catch (Exception e)
            {
                return false;
            }
        }
        return true;
    }

    public boolean isNoteValidCheck(String note)
    {
        return areNotesValidCheck(new ArrayList<String>(Arrays.asList(note)));
    }

    public boolean areNoteIdsValidCheck(ArrayList<Integer> noteIds)
    {
        AllNotes allNotes = new AllNotes();

        for (int noteId: noteIds)
        {
            try{
                allNotes.getNoteById(noteId);
            }
            catch (Exception e)
            {
                return false;
            }
        }
        return true;
    }

    public boolean isNoteIdValidCheck(int noteId)
    {
        return areNoteIdsValidCheck(new ArrayList<Integer>(Arrays.asList(noteId)));
    }
}
