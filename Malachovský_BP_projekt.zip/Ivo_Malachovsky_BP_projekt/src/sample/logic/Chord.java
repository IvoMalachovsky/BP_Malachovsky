package sample.logic;

import java.util.ArrayList;

public class Chord {
    private ArrayList<String> notes = new ArrayList<String>();
    private String name;
    private int inversion;

    private NoteOperations nop = new NoteOperations();

    private void generalGeneration(int inversion, Scale tempScale, int numberOfNotes)
    {
        this.inversion = inversion;

        numberOfNotes = (numberOfNotes*2)-1;

        for (int i = 0; i<numberOfNotes; i+=2)
        {
            notes.add(tempScale.getScaleNotes().get(i));
        }

        switchToAccidentals();

        applyInversion(inversion);
        validityCheck(false);
    }

    private void generalPartialGeneration(int inversion, Scale tempScale, int numberOfNotes)
    {
        this.inversion = inversion;

        numberOfNotes = (numberOfNotes*2)-1;

        for (int i = 0; i<numberOfNotes; i+=2)
        {
            notes.add(tempScale.getScaleNotes().get(i));
        }

        switchToAccidentals();
    }

    public void generateMajorChord(String rootNote, int inversion)
    {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalGeneration(inversion, tempScale, 3);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Dur";
    }

    public void generateMinorChord(String rootNote, int inversion)
    {
        Scale tempScale = new Scale();
        tempScale.generateMinorNScale(rootNote);
        generalGeneration(inversion, tempScale, 3);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Moll";
    }

    public void generateDiminishedChord(String rootNote, int inversion)
    {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalPartialGeneration(inversion, tempScale, 3);

        notes.set(1, notes.get(1)+"b");
        notes.set(2, notes.get(2)+"b");

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Zmenšený";
    }

    public void generateAugmentedChord(String rootNote, int inversion)
    {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalPartialGeneration(inversion, tempScale, 3);

        notes.set(2, notes.get(2)+"#");

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Zvětšený";
    }

    public void generateSusTwoChord(String rootNote, int inversion)
    {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        notes.add(tempScale.getScaleNotes().get(0));
        notes.add(tempScale.getScaleNotes().get(1));
        notes.add(tempScale.getScaleNotes().get(4));

        this.inversion = inversion;

        switchToAccidentals();

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Sus2";
    }

    public void generateSusFourChord(String rootNote, int inversion)
    {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);

        notes.add(tempScale.getScaleNotes().get(0));
        notes.add(tempScale.getScaleNotes().get(3));
        notes.add(tempScale.getScaleNotes().get(4));

        this.inversion = inversion;
        switchToAccidentals();

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Sus4";
    }

    public void generateSeventhOneChord(String rootNote, int inversion)
    {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalGeneration(inversion, tempScale, 4);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Septakord: Tvrdě velký";
    }
    public void generateSeventhTwoChord(String rootNote, int inversion) {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalPartialGeneration(inversion, tempScale, 4);

        notes.set(3, notes.get(3) + "b");

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Septakord: Tvrdě malý";
    }

    public void generateSeventhThreeChord(String rootNote, int inversion) {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalPartialGeneration(inversion, tempScale, 4);

        notes.set(1, notes.get(1) + "b");

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Septakord: Měkce velký";
    }

    public void generateSeventhFourChord(String rootNote, int inversion) {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalPartialGeneration(inversion, tempScale, 4);

        notes.set(1, notes.get(1) + "b");
        notes.set(3, notes.get(3) + "b");

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Septakord: Měkce malý";
    }

    public void generateSeventhFiveChord(String rootNote, int inversion) {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalPartialGeneration(inversion, tempScale, 4);

        notes.set(2, notes.get(2) + "#");

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Septakord: Zvětšeně velký";
    }

    public void generateSeventhSixChord(String rootNote, int inversion) {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalPartialGeneration(inversion, tempScale, 4);

        notes.set(1, notes.get(1) + "b");
        notes.set(2, notes.get(2) + "b");
        notes.set(3, notes.get(3) + "b");

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Septakord: Zmenšeně malý";
    }

    public void generateSeventhSevenChord(String rootNote, int inversion) {
        Scale tempScale = new Scale();
        tempScale.generateMajorScale(rootNote);
        generalPartialGeneration(inversion, tempScale, 4);

        notes.set(1, notes.get(1) + "b");
        notes.set(2, notes.get(2) + "b");
        notes.set(3, notes.get(3) + "bb");

        applyInversion(inversion);
        validityCheck(false);
        name = nop.removeOctaveNumber(nop.signatureToAccidentals(rootNote)) + " Septakord: Zmenšeně zmenšený";
    }


    public void generateChord(String i, String baseNote, int inversion)
    {
        if(i.equals("Dur"))
        {
            generateMajorChord(baseNote, inversion);
        }
        if(i.equals("Moll")) {
            generateMinorChord(baseNote, inversion);
        }
        if(i.equals("Zvětšený")) {
            generateAugmentedChord(baseNote, inversion);
        }
        if(i.equals("Zmenšený")) {
            generateDiminishedChord(baseNote, inversion);
        }
        if(i.equals("Sus2")) {
            generateSusTwoChord(baseNote, inversion);
        }
        if(i.equals("Sus4")) {
            generateSusFourChord(baseNote, inversion);
        }
        if(i.equals("Septakord: Tvrdě velký")) {
            generateSeventhOneChord(baseNote, inversion);
        }
        if(i.equals("Septakord: Tvrdě malý")) {
            generateSeventhTwoChord(baseNote, inversion);
        }
        if(i.equals("Septakord: Měkce velký")) {
            generateSeventhThreeChord(baseNote, inversion);
        }
        if(i.equals("Septakord: Měkce malý")) {
            generateSeventhFourChord(baseNote, inversion);
        }
        if(i.equals("Septakord: Zvětšeně velký")) {
            generateSeventhFiveChord(baseNote, inversion);
        }
        if(i.equals("Septakord: Zmenšeně malý")) {
            generateSeventhSixChord(baseNote, inversion);
        }
        if(i.equals("Septakord: Zmenšeně zmenšený")) {
            generateSeventhSevenChord(baseNote, inversion);
        }

    }

    private void switchToAccidentals()
    {
        String symbols="";
        String newSymbols = "";

        for (int i = 0; i<notes.size(); i++)
        {
            if(notes.get(i).length() > 2)
            {
                symbols = notes.get(i).substring(2);
            }
            else
            {
                symbols = "";
            }
            for (int j = 0; j<symbols.length(); j++)
            {
                if(symbols.charAt(j) == 's' || symbols.charAt(j) == '#')
                {
                    newSymbols = newSymbols + "#";
                }
                else if(symbols.charAt(j) == 'f' || symbols.charAt(j) == 'b')
                {
                    newSymbols = newSymbols + "b";
                }
            }
            notes.set(i, notes.get(i).substring(0,2)+newSymbols);
            newSymbols="";
        }

    }

    public void applyInversion(int inversion)
    {
        NoteOperations nOp = new NoteOperations();
        String tempNote;

        for(int i = 0; i<inversion;i++) {

            tempNote = notes.get(0);
            notes.remove(0);
            tempNote = nOp.increaseOctave(tempNote);
            notes.add(tempNote);
        }

    }

    private void changeOctaveFullChord(boolean increase)
    {
        NoteOperations nOp = new NoteOperations();
        if(increase)
        {
            for (int i = 0; i < notes.size(); i++)
            {
                notes.set(i, nOp.increaseOctave(notes.get(i)));
            }
        }
        else
        {
            for (int i = 0; i < notes.size(); i++)
            {
                notes.set(i, nOp.decreaseOctave(notes.get(i)));
            }
        }
    }

    private void validityCheck(boolean secondTime)
    {
        AllNotes allNotes = new AllNotes();

        for (String note: notes)
        {
            try{
                if(allNotes.translateStringNote(note) != null)
                {
                    System.out.println("Note is not null");
                }
            }
            catch (Exception e)
            {
                if(!secondTime) {
                    changeOctaveFullChord(false);
                    validityCheck(true);
                }
                else
                {
                    changeOctaveFullChord(true);
                    changeOctaveFullChord(true);
                }

            }

        }
    }

    public ArrayList<String> getNotes() {
        return notes;
    }

    public void printChord()
    {
        System.out.println(notes);
    }

    public String getName() {
        return name;
    }

    public int getInversion() {
        return inversion;
    }
}
