package sample.logic;

import java.util.ArrayList;
import java.util.Arrays;

public class FullNotes {
    private ArrayList<String> notes = new ArrayList<String>();

    public FullNotes()
    {
        notes.add("G0");
        notes.add("A0");
        notes.add("H0");
        notes.add("C1");
        notes.add("D1");
        notes.add("E1");
        notes.add("F1");
        notes.add("G1");
        notes.add("A1");
        notes.add("H1");
        notes.add("C2");
        notes.add("D2");
        notes.add("E2");
        notes.add("F2");
        notes.add("G2");
        notes.add("A2");
        notes.add("H2");
        notes.add("C3");
        notes.add("D3");
        notes.add("E3");
        notes.add("F3");
    }

    public String getFullNoteById(int id)
    {
        return notes.get(id);
    }

    public String findFullNote(String note)
    {
        note = note.substring(0,2);
        for(int i = 0; i<notes.size();i++)
        {
            if(note.equals(notes.get(i)))
            {
                return notes.get(i);
            }
        }
        return null;
    }

    public int findIdOfAFullNote(String note)
    {
        note = note.substring(0,2);
        for(int i = 0; i<notes.size();i++)
        {
            if(note.equals(notes.get(i)))
            {
                return i;
            }
        }
        return -1;
    }

    public boolean areNotesValidCheck(ArrayList<String> notes)
    {
        for (String note: notes)
        {
            try{
                findIdOfAFullNote(note);
            }
            catch (Exception e)
            {
                return false;
            }
        }
        return true;
    }

    public boolean isNoteValidCheck(String note)
    {
        return areNotesValidCheck(new ArrayList<String>(Arrays.asList(note)));
    }

    public boolean areNoteIdsValidCheck(ArrayList<Integer> noteIds)
    {
        for (int noteId: noteIds)
        {
            try{
                getFullNoteById(noteId);
            }
            catch (Exception e)
            {
                return false;
            }
        }
        return true;
    }

    public boolean isNoteIdValidCheck(int noteId)
    {
        return areNoteIdsValidCheck(new ArrayList<Integer>(Arrays.asList(noteId)));
    }
}
