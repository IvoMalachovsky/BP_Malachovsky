package sample.logic;

import java.util.ArrayList;
import java.util.Arrays;

public class NoteOperations {

    public String changeOctave(String note, int octave)
    {
        if (note.length() > 2) {
            note = note.charAt(0) + String.valueOf(octave) + note.substring(2);
        } else {
            note = note.charAt(0) + String.valueOf(octave);
        }

        return note;
    }

    public String increaseOctave(String note)
    {
        return changeOctave(note, ((Integer.parseInt(note.substring(1,2)))+(1)));
    }

    public String decreaseOctave(String note)
    {
        return changeOctave(note, ((Integer.parseInt(note.substring(1,2)))-(1)));
    }

    public ArrayList<String> decreaseOctaveMultiple(ArrayList<String> notes)
    {
        ArrayList<String> tempNotes = new ArrayList<String>();

        for(String note: notes)
        {
            tempNotes.add(decreaseOctave(note));
        }

        return tempNotes;

    }

    public ArrayList<String> increaseOctaveMultiple(ArrayList<String> notes)
    {
        ArrayList<String> tempNotes = new ArrayList<String>();

        for(String note: notes)
        {
            tempNotes.add(increaseOctave(note));
        }

        return tempNotes;

    }

    public String removeOctaveNumber(String note)
    {
        if (note.length() > 2) {
            note = note.substring(0,1) + note.substring(2);
        } else {
            note = note.substring(0,1);
        }

        return note;
    }

    public String signatureToAccidentals(String note)
    {
        String symbols="";
        String newSymbols = "";

            if(note.length() > 2)
            {
                symbols = note.substring(2);
            }
            else
            {
                symbols = "";
            }
            for (int j = 0; j<symbols.length(); j++)
            {
                if(symbols.charAt(j) == 's' || symbols.charAt(j) == '#')
                {
                    newSymbols = newSymbols + "#";
                }
                else if(symbols.charAt(j) == 'f' || symbols.charAt(j) == 'b')
                {
                    newSymbols = newSymbols + "b";
                }
            }
            note = note.substring(0,2)+newSymbols;

            return note;
    }

    public ArrayList<String> signatureToAccidentalsMultiple(ArrayList<String> notes)
    {
        ArrayList<String> tempNotes = new ArrayList<String>();

        for(String note: notes)
        {
            tempNotes.add(signatureToAccidentals(note));
        }

        return tempNotes;
    }

    public String normalizeNote(String note)
    {
        AllNotes an = new AllNotes();
        int tempNoteIndex = an.translateStringNote(note).getId();

        note = an.getNoteById(tempNoteIndex).getName();
        if(note.length() > 1)
        {
           note = note.substring(0,1) +  an.getNoteById(tempNoteIndex).getOctave() + note.substring(1);
        }
        else
        {
            note = note +  an.getNoteById(tempNoteIndex).getOctave();
        }

        return note;
    }

    public String translateAccidentalToSuffix(String noOctaveNumberNote)
    {
        String toReturn = noOctaveNumberNote;

        if(noOctaveNumberNote.length() > 1)
        {
            if(noOctaveNumberNote.charAt(1) == '#' || noOctaveNumberNote.charAt(1) == 's')
            {
                toReturn = noOctaveNumberNote.substring(0,1) + "is";
            }
            else if (noOctaveNumberNote.charAt(1) == 'f' || noOctaveNumberNote.charAt(1) == 'b')
            {
                if(noOctaveNumberNote.equals("Ab") || noOctaveNumberNote.equals("Af") || noOctaveNumberNote.equals("Eb") || noOctaveNumberNote.equals("Ef"))
                {
                    toReturn = noOctaveNumberNote.substring(0,1) + "s";
                }
                else if(noOctaveNumberNote.equals("Hb") || noOctaveNumberNote.equals("Hf"))
                {
                    toReturn = "B";
                }
                else {
                    toReturn = noOctaveNumberNote.substring(0, 1) + "es";
                }
            }
        }


        return toReturn;
    }



}
