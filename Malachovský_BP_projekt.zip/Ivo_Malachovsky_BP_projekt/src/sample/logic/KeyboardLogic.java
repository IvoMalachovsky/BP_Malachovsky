package sample.logic;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import sample.controllers.ControllerExerciseEndScreen;

import java.io.IOException;
import java.util.ArrayList;

public class KeyboardLogic {

    public ArrayList<String> activeKeys = new ArrayList<String>();
    private String selectedKey = "#B0FEB5";


    public void initializeActiveKeys()
    {
        activeKeys.add("xC1");activeKeys.add("xC1s");activeKeys.add("xD1");activeKeys.add("xD1s");activeKeys.add("xE1");activeKeys.add("xF1");activeKeys.add("xF1s");
        activeKeys.add("xG1");activeKeys.add("xG1s");activeKeys.add("xA1");activeKeys.add("xA1s");activeKeys.add("xH1");
        activeKeys.add("xC2");activeKeys.add("xC2s");activeKeys.add("xD2");activeKeys.add("xD2s");activeKeys.add("xE2");activeKeys.add("xF2");activeKeys.add("xF2s");
        activeKeys.add("xG2");activeKeys.add("xG2s");activeKeys.add("xA2");activeKeys.add("xA2s");activeKeys.add("xH2");
    }

    public void wKeyChange(Rectangle rectangle)
    {
        activateKey(rectangle);

        if(rectangle.getFill().toString().equals("0xffffffff"))
        {
            rectangle.setFill(Color.web(selectedKey));
        }
        else
        {
            rectangle.setFill(Color.web("0xffffffff"));
        }

    }

    public void bKeyChange(Rectangle rectangle)
    {
        activateKey(rectangle);

        if(rectangle.getFill().toString().equals("0x000000ff"))
        {
            rectangle.setFill(Color.web(selectedKey));
        }
        else
        {
            rectangle.setFill(Color.web("0x000000ff"));
        }

    }

    private void activateKey(Rectangle rectangle)
    {
        if(activeKeys.contains("x"+rectangle.getId()))
        {
            activeKeys.set(activeKeys.indexOf("x"+rectangle.getId()),rectangle.getId());
        }
        else
        {
            activeKeys.set(activeKeys.indexOf(rectangle.getId()),"x"+rectangle.getId());
        }
    }

    public boolean checkTheCorrectAnswer (ArrayList<String> answer)
    {
        AllNotes allNotes = new AllNotes();

        boolean correctAnswer = true;
        ArrayList<String> tempActiveKeys = new ArrayList<String>();

        for(int i = 0; i<activeKeys.size(); i++)
        {
            if(!(activeKeys.get(i).charAt(0)=='x'))
            {
                tempActiveKeys.add(activeKeys.get(i));
            }
        }

        if(answer.size() == tempActiveKeys.size()) {
            for (int i = 0; i < tempActiveKeys.size(); i++) {
                if (!(allNotes.translateStringNote(tempActiveKeys.get(i)).getName().equals(allNotes.translateStringNote(answer.get(i)).getName()))) {
                    correctAnswer = false;
                }
            }
        }
        else {correctAnswer = false;}

        if(tempActiveKeys.size() == 0)
        {
            correctAnswer = false;
        }

        return correctAnswer;
    }
}
