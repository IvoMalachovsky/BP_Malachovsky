package sample.logic;

import sample.exercises.ScaleNameKey.ScaleNameKeyQuestion;

import java.util.ArrayList;

public class GeneralGeneration {

    public String generateNote(ArrayList<String> tempNotes, int randomTonic) {
        String generatedNote = "";

        while (true) {

            if (tempNotes.contains("C?")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "C?";
                    tempNotes.remove("C?");
                    break;
                }
            }

            if (tempNotes.contains("D?")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "D?";
                    tempNotes.remove("D?");
                    break;
                }
            }

            if (tempNotes.contains("E?")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "E?";
                    tempNotes.remove("E?");
                    break;
                }
            }

            if (tempNotes.contains("F?")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "F?";
                    tempNotes.remove("F?");
                    break;
                }
            }

            if (tempNotes.contains("G?")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "G?";
                    tempNotes.remove("G?");
                    break;
                }
            }

            if (tempNotes.contains("A?")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "A?";
                    tempNotes.remove("A?");
                    break;
                }
            }

            if (tempNotes.contains("H?")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "H?";
                    tempNotes.remove("H?");
                    break;
                }
            }

            if (tempNotes.contains("C?s")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "C?s";
                    tempNotes.remove("C?s");
                    break;
                }
            }

            if (tempNotes.contains("D?s")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "D?s";
                    tempNotes.remove("D?s");
                    break;
                }
            }

            if (tempNotes.contains("E?s")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "E?s";
                    tempNotes.remove("E?s");
                    break;
                }
            }

            if (tempNotes.contains("F?s")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "F?s";
                    tempNotes.remove("F?s");
                    break;
                }
            }

            if (tempNotes.contains("G?s")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "G?s";
                    tempNotes.remove("G?s");
                    break;
                }
            }

            if (tempNotes.contains("A?s")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "A?s";
                    tempNotes.remove("A?s");
                    break;
                }
            }

            if (tempNotes.contains("H?s")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "H?s";
                    tempNotes.remove("H?s");
                    break;
                }
            }

            if (tempNotes.contains("C?f")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "C?f";
                    tempNotes.remove("C?f");
                    break;
                }
            }

            if (tempNotes.contains("D?f")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "D?f";
                    tempNotes.remove("D?f");
                    break;
                }
            }

            if (tempNotes.contains("E?f")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "E?f";
                    tempNotes.remove("E?f");
                    break;
                }
            }

            if (tempNotes.contains("F?f")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "F?f";
                    tempNotes.remove("F?f");
                    break;
                }
            }

            if (tempNotes.contains("G?f")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "G?f";
                    tempNotes.remove("G?f");
                    break;
                }
            }

            if (tempNotes.contains("A?f")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "A?f";
                    tempNotes.remove("A?f");
                    break;
                }
            }

            if (tempNotes.contains("H?f")) {
                randomTonic--;
                if (randomTonic <= 0) {
                    generatedNote = "H?f";
                    tempNotes.remove("H?f");
                    break;
                }
            }
        }

        return generatedNote;
    }

    public String addGeneratedOctave(ArrayList<Integer> tempOctave, int randomOctave, String root) {
        while (true) {
            AllNotes allNotes = new AllNotes();
            NoteOperations nOp = new NoteOperations();

            if (tempOctave.contains(2)) {
                int octave = 2;

                randomOctave--;
                if (randomOctave <= octave) {
                    root = nOp.changeOctave(root, octave);

                    try
                    {
                        allNotes.translateStringNote(nOp.increaseOctave(root));
                    }
                    catch (Exception e)
                    {
                        octave=0;
                        root = nOp.changeOctave(root, octave);
                    }

                    tempOctave.remove((Object) 2);
                    if(root.equals("G0f")){root = nOp.changeOctave(root, 1);}
                    return root;
                }
            }
            if (tempOctave.contains(1)) {
                int octave = 1;

                randomOctave--;
                if (randomOctave <= octave) {
                    root = nOp.changeOctave(root, octave);

                    tempOctave.remove((Object) 1);
                    return root;
                }
            }
        }

    }

    public String generateStaffKey(ArrayList<String> tempKeys, int randomKey)
    {
        String tempKey = "";

        while (true) {
            if (tempKeys.contains("treble")) {
                randomKey--;
                if (randomKey <= 0) {
                    tempKey = "treble";
                    tempKeys.remove("treble");
                    break;
                }
            }

            if (tempKeys.contains("bass")) {
                randomKey--;
                if (randomKey <= 0) {
                    tempKey = "bass";
                    tempKeys.remove("bass");
                    break;
                }
            }
        }
        return tempKey;
    }
    public boolean generateIntervalDirection(ArrayList<String> tempDirections, int randomDirection) {
        boolean tempDirection = true;

        while (true) {
            if (tempDirections.contains("asc")) {
                randomDirection--;
                if (randomDirection <= 0) {
                    tempDirections.remove("asc");
                    break;
                }
            }

            if (tempDirections.contains("dcs")) {
                randomDirection--;
                if (randomDirection <= 0) {
                    tempDirection = false;
                    tempDirections.remove("dcs");
                    break;
                }
            }
        }

        return tempDirection;
    }

    public ArrayList<String> viableNoteAnswers(ArrayList<String> notes)
    {
        ArrayList<String> toReturn = new ArrayList<String>();
        String tempNote;

        for(String note:notes)
        {
            tempNote = note.substring(0,1);
            if(!toReturn.contains(tempNote))
            {
                toReturn.add(tempNote);
            }
        }

        return toReturn;
    }

    public ArrayList<String> viableAccidentalsAnswers(ArrayList<String> notes)
    {
        ArrayList<String> toReturn = new ArrayList<String>();

        boolean containsNoAccidental=false;
        boolean containsSharp=false;
        boolean containsFlat=false;

        for(String note:notes)
        {
            if(note.length()<=2)
            {
                containsNoAccidental = true;
            }
            if(note.contains("s"))
            {
                containsSharp = true;
            }
            if(note.contains("f"))
            {
                containsFlat = true;
            }
        }

        if(containsNoAccidental)
        {
            toReturn.add("");
        }
        if(containsSharp)
        {
            toReturn.add("#");
        }
        if(containsFlat)
        {
            toReturn.add("b");
        }

        return toReturn;
    }

}
