package sample.logic;

import java.util.ArrayList;

public class Scale {
    private AllNotes allNotes = new AllNotes();

    private NoteOperations nOp = new NoteOperations();

    private String name;
    private ArrayList<String> scaleNotes = new ArrayList<String>();
    private ArrayList<String> scaleNotesDown = new ArrayList<String>();

    public void generateMajorScale(String baseNote)
    {
        name = nOp.removeOctaveNumber(nOp.signatureToAccidentals(baseNote))+" Dur";
        ArrayList<Integer> template = new ArrayList<Integer>();
        template.add(2);template.add(2); template.add(1);
        template.add(2);template.add(2);template.add(2);template.add(1);

        generalGeneration(baseNote, 8);
        applyTemplate(template);
        generateDownwardCopyOfScale();
    }

    public void generateMinorNScale(String baseNote)
    {
        name = nOp.removeOctaveNumber(nOp.signatureToAccidentals(baseNote)) +" Moll - přirozená";
        ArrayList<Integer> template = new ArrayList<Integer>();
        template.add(2);template.add(1); template.add(2);
        template.add(2);template.add(1);template.add(2);template.add(2);

        generalGeneration(baseNote, 8);
        applyTemplate(template);
        generateDownwardCopyOfScale();
    }

    public void generateMinorHScale(String baseNote)
    {
        generateMinorNScale(baseNote);
        name = nOp.removeOctaveNumber(nOp.signatureToAccidentals(baseNote))+" Moll - harmonická";
        scaleNotes.set(6,scaleNotes.get(6)+"#");
        scaleNotesDown.set(1,scaleNotesDown.get(1)+"#");
    }
    public void generateMinorMScale(String baseNote)
    {
        generateMinorNScale(baseNote);
        name = nOp.removeOctaveNumber(nOp.signatureToAccidentals(baseNote))+" Moll - melodická";
        scaleNotes.set(5,scaleNotes.get(5)+"#");
        scaleNotes.set(6,scaleNotes.get(6)+"#");
    }

    public void generateDorianScale(String baseNote)
    {
        name = nOp.removeOctaveNumber(nOp.signatureToAccidentals(baseNote))+" Dórská";
        ArrayList<Integer> template = new ArrayList<Integer>();
        template.add(2);template.add(1); template.add(2);
        template.add(2);template.add(2);template.add(1);template.add(2);

        generalGeneration(baseNote, 8);
        applyTemplate(template);
        generateDownwardCopyOfScale();
    }

    public void generatePhrygianScale(String baseNote)
    {
        name = nOp.removeOctaveNumber(nOp.signatureToAccidentals(baseNote))+" Frygická";
        ArrayList<Integer> template = new ArrayList<Integer>();
        template.add(1);template.add(2); template.add(2);
        template.add(2);template.add(1);template.add(2);template.add(2);

        generalGeneration(baseNote, 8);
        applyTemplate(template);
        generateDownwardCopyOfScale();
    }

    public void generateLydianScale(String baseNote)
    {
        name = nOp.removeOctaveNumber(nOp.signatureToAccidentals(baseNote))+" Lydická";
        ArrayList<Integer> template = new ArrayList<Integer>();
        template.add(2);template.add(2); template.add(2);
        template.add(1);template.add(2);template.add(2);template.add(1);

        generalGeneration(baseNote, 8);
        applyTemplate(template);
        generateDownwardCopyOfScale();
    }

    public void generateMixolydianScale(String baseNote)
    {
        name = nOp.removeOctaveNumber(nOp.signatureToAccidentals(baseNote))+" Mixolydická";
        ArrayList<Integer> template = new ArrayList<Integer>();
        template.add(2);template.add(2); template.add(1);
        template.add(2);template.add(2);template.add(1);template.add(2);

        generalGeneration(baseNote, 8);
        applyTemplate(template);
        generateDownwardCopyOfScale();
    }

    public void generateWholeScale(String baseNote)
    {
        name = nOp.removeOctaveNumber(nOp.signatureToAccidentals(baseNote))+" Celotónová";
        ArrayList<Integer> template = new ArrayList<Integer>();
        template.add(2);template.add(2); template.add(2);
        template.add(2);template.add(2);template.add(2);

        generalGeneration(baseNote, 7);
        applyTemplate(template);
        scaleNotes.set(6, setNoteOctaveHigher(scaleNotes.get(0)));
        scaleNotes = new ArrayList<String>(nOp.signatureToAccidentalsMultiple(scaleNotes));
        generateDownwardCopyOfScale();
    }

    private String setNoteOctaveHigher(String note)
    {
        int octave = Integer.parseInt(note.substring(1,2));
        octave++;
        String toReturn="";

        if(note.length() > 2)
        {
            toReturn = note.substring(0,1) + octave + note.substring(2);
        }
        else
        {
            toReturn = note.substring(0,1) + octave;
        }

        return toReturn;
    }

    private void generalGeneration(String baseNote, int numberOfNotes)
    {
        scaleNotes = new ArrayList<String>();
        scaleNotesDown = new ArrayList<String>();

        FullNotes fullNotes = new FullNotes();
        int tempId;

        scaleNotes.add(baseNote);
        tempId = fullNotes.findIdOfAFullNote(baseNote);
        if(tempId == -1)
        {
            return;
        }
        for(int i = 1; i<numberOfNotes; i++)
        {
            scaleNotes.add(fullNotes.getFullNoteById(tempId+i));
        }

    }

    public void printScaleUpward()
    {
        for(int i = 0; i<scaleNotes.size(); i++)
        {
            System.out.println(scaleNotes.get(i));
        }
    }

    public void printScaleDownward()
    {
        for(int i = 0; i<scaleNotesDown.size(); i++)
        {
            System.out.println(scaleNotesDown.get(i));
        }
    }

    private int findIntervalTwoNotes(String strNote1, String strNote2)
    {
        int tempId1 = allNotes.translateStringNote(strNote1).getId();
        int tempId2 = allNotes.translateStringNote(strNote2).getId();

        return tempId2 - tempId1;
    }

    private void applyTemplate(ArrayList<Integer> template)
    {
        int i = 0;

        for (;i<scaleNotes.size()-1;)
        {
            if(findIntervalTwoNotes(scaleNotes.get(i),scaleNotes.get(i+1)) < template.get(i))
            {
                scaleNotes.set(i+1, scaleNotes.get(i+1)+"s");
                i = 0;
            }
            else if(findIntervalTwoNotes(scaleNotes.get(i),scaleNotes.get(i+1)) > template.get(i))
            {
                scaleNotes.set(i+1, scaleNotes.get(i+1)+"f");
                i = 0;
            }
            else
            {
                i++;
            }

        }
    }

    private void generateDownwardCopyOfScale()
    {
        for(int i = 0; i<scaleNotes.size(); i++)
        {
            scaleNotesDown.add(scaleNotes.get(scaleNotes.size()-i-1));
        }
    }

    public ArrayList<String> getScaleNotes() {
        return scaleNotes;
    }

    public ArrayList<String> getScaleNotesDown() {
        return scaleNotesDown;
    }

    public String getName() {
        return name;
    }

    public void generateScale(String scaleType, String baseNote) {
        if(scaleType.equals("Dur"))
        {
            generateMajorScale(baseNote);
        }
        if(scaleType.equals("Moll - přirozená")) {
            generateMinorNScale(baseNote);
        }
        if(scaleType.equals("Moll - harmonická")) {
            generateMinorHScale(baseNote);
        }
        if(scaleType.equals("Moll - melodická")) {
            generateMinorMScale(baseNote);
        }
        if(scaleType.equals("Dórská")) {
            generateDorianScale(baseNote);
        }
        if(scaleType.equals("Frygická")) {
            generatePhrygianScale(baseNote);
        }
        if(scaleType.equals("Lydická")) {
            generateLydianScale(baseNote);
        }
        if(scaleType.equals("Mixolydická")) {
            generateMixolydianScale(baseNote);
        }
        if(scaleType.equals("Celotónová")) {
            generateWholeScale(baseNote);
        }
    }
}
