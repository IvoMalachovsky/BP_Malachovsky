package sample.logic;

public class Note {
    private String name;
    private int octave;
    private int id;

    public Note(String name, int octave, int id) {
        this.name = name;
        this.octave = octave;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getOctave() {
        return octave;
    }

    public int getId() {
        return id;
    }

    public String getPrintableElements()
    {
        return name+" "+octave+" "+id;
    }
}
