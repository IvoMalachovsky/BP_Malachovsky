package sample.logic;

import java.util.ArrayList;
import java.util.Arrays;

public class Interval {
    private String intervalName;
    private String noteOne;
    private String noteTwo;
    private boolean ascending;

    public void generateInterval(String baseNote, int intervalNumber, char intervalType, boolean ascending)
    {
        FullNotes fullNotes = new FullNotes();
        NoteOperations nop = new NoteOperations();

        noteOne = baseNote;

        int secondNoteId;
        String tempSecondNote;


        if(ascending){
            secondNoteId = fullNotes.findIdOfAFullNote(noteOne) + intervalNumber;
            if(!fullNotes.isNoteIdValidCheck(secondNoteId))
            {
                noteOne = nop.decreaseOctave(noteOne);
                secondNoteId = fullNotes.findIdOfAFullNote(noteOne) + intervalNumber;
            }
        }
        else
        {
            secondNoteId = fullNotes.findIdOfAFullNote(noteOne) - intervalNumber;
            if(!fullNotes.isNoteIdValidCheck(secondNoteId))
            {
                noteOne = nop.increaseOctave(noteOne);
                secondNoteId = fullNotes.findIdOfAFullNote(noteOne) - intervalNumber;
            }
        }

        tempSecondNote = fullNotes.getFullNoteById(secondNoteId);

        int inputInterval = findIntervalTwoNotes(noteOne, tempSecondNote, ascending);
        tempSecondNote = tuneInterval(noteOne, tempSecondNote, inputInterval, intervalNumber, intervalType, ascending);

        noteTwo = tempSecondNote;
        intervalName = createIntervalName(intervalNumber, intervalType);
        this.ascending = ascending;

        noteOne = nop.signatureToAccidentals(noteOne);

    }

    private String createIntervalName(int intervalNumber, char intervalType)
    {
        String name = "";

        if(intervalType == 'm')
        {
            if(intervalNumber == 0 || intervalNumber == 3 || intervalNumber == 4 || intervalNumber == 7)
            {
                name = name + "Čistá ";
            }
            else {
                name = name + "Malá ";
            }

        }
        else if(intervalType == 'a')
        {
            name = name + "Zvětšená ";
        }
        else if(intervalType == 'd')
        {
            name = name + "Zmenšená ";
        }
        else if(intervalType == 'v')
        {
            if(intervalNumber == 0 || intervalNumber == 3 || intervalNumber == 4 || intervalNumber == 7)
            {
                name = name + "Čistá ";
            }
            else {
                name = name + "Velká ";
            }
        }

        if(intervalNumber == 0)
        {
            name = name + "Prima";
        }
        else if(intervalNumber == 1)
        {
            name = name + "Sekunda";
        }
        else if(intervalNumber == 2)
        {
            name = name + "Tercie";
        }
        else if(intervalNumber == 3)
        {
            name = name + "Kvarta";
        }
        else if(intervalNumber == 4)
        {
            name = name + "Kvinta";
        }
        else if(intervalNumber == 5)
        {
            name = name + "Sexta";
        }
        else if(intervalNumber == 6)
        {
            name = name + "Septima";
        }
        else if(intervalNumber == 7)
        {
            name = name + "Oktáva";
        }

        return name;
    }

    private String tuneInterval(String baseNote ,String tempSecondNote, int inputInterval, int desiredIntervalNumber, char desiredIntervalType, boolean ascending) {

        NoteOperations nop = new NoteOperations();

        while(inputInterval != intervalToSemitones(desiredIntervalNumber, desiredIntervalType)) {
            if(ascending) {
                if (inputInterval < intervalToSemitones(desiredIntervalNumber, desiredIntervalType)) {
                    tempSecondNote = tempSecondNote + "#";
                    try{ inputInterval = findIntervalTwoNotes(baseNote, tempSecondNote, ascending);}
                    catch (Exception e){
                        baseNote = nop.decreaseOctave(baseNote);
                        noteOne = baseNote;
                        tempSecondNote = nop.decreaseOctave(tempSecondNote);
                        inputInterval = findIntervalTwoNotes(baseNote, tempSecondNote, ascending);
                    }

                } else if (inputInterval > intervalToSemitones(desiredIntervalNumber, desiredIntervalType)) {
                    tempSecondNote = tempSecondNote + "b";
                    inputInterval = findIntervalTwoNotes(baseNote, tempSecondNote, ascending);
                }
            }
            else {
                if (inputInterval < intervalToSemitones(desiredIntervalNumber, desiredIntervalType)) {
                    tempSecondNote = tempSecondNote + "b";
                    try{ inputInterval = findIntervalTwoNotes(baseNote, tempSecondNote, ascending);}
                    catch (Exception e){
                        baseNote = nop.increaseOctave(baseNote);
                        noteOne = baseNote;
                        tempSecondNote = nop.increaseOctave(tempSecondNote);
                        inputInterval = findIntervalTwoNotes(baseNote, tempSecondNote, ascending);
                    }
                } else if (inputInterval > intervalToSemitones(desiredIntervalNumber, desiredIntervalType)) {
                    tempSecondNote = tempSecondNote + "#";
                    inputInterval = findIntervalTwoNotes(baseNote, tempSecondNote, ascending);
                }
            }
        }

        return tempSecondNote;
    }

    private int findIntervalTwoNotes(String strNote1, String strNote2, boolean ascending)
    {
        AllNotes allNotes = new AllNotes();

        int tempId1 = allNotes.translateStringNote(strNote1).getId();
        int tempId2 = allNotes.translateStringNote(strNote2).getId();
        int result;

        if(ascending) {
             result = (tempId2) - (tempId1);
        }
        else {result = (tempId1) - (tempId2);}

        return result;

    }

    public int intervalToSemitones(int intervalNumber, char intervalType)
    {
        int returnAnswer=0;

        if(intervalNumber == 0 || intervalNumber == 1 || intervalNumber == 2)
        {
            returnAnswer = 2 * intervalNumber;
        }
        else if(intervalNumber == 3)
        {
            returnAnswer = 5;
        }
        else if(intervalNumber == 4)
        {
            returnAnswer = 7;
        }
        else if(intervalNumber == 5 || intervalNumber == 6)
        {
            returnAnswer = (intervalNumber * 2) - 1;
        }
        else if(intervalNumber == 7)
        {
            returnAnswer = 12;
        }

        if(intervalType == 'm')
        {
            if(intervalNumber == 0 || intervalNumber == 3 || intervalNumber == 4 || intervalNumber == 7){
                intervalType = 'v';
            }
            else {
                returnAnswer--;
            }
        }

        else if(intervalType == 'a')
        {

            returnAnswer++;

        }

        else if(intervalType == 'd')
        {

            if (intervalNumber == 1 || intervalNumber == 2 || intervalNumber == 5 || intervalNumber == 6) { returnAnswer -= 2;}
            else {returnAnswer--;}

        }

        return returnAnswer;
    }

    public String getIntervalName() {
        return intervalName;
    }

    public String getNoteOne() {
        return noteOne;
    }

    public String getNoteTwo() {
        return noteTwo;
    }

    public boolean isAscending() {
        return ascending;
    }

    public String translateIntervalNumber(int intervalNumber)
    {
        String name="";

        if(intervalNumber == 0)
        {
            name = name + "Prima";
        }
        else if(intervalNumber == 1)
        {
            name = name + "Sekunda";
        }
        else if(intervalNumber == 2)
        {
            name = name + "Tercie";
        }
        else if(intervalNumber == 3)
        {
            name = name + "Kvarta";
        }
        else if(intervalNumber == 4)
        {
            name = name + "Kvinta";
        }
        else if(intervalNumber == 5)
        {
            name = name + "Sexta";
        }
        else if(intervalNumber == 6)
        {
            name = name + "Septima";
        }
        else if(intervalNumber == 7)
        {
            name = name + "Oktáva";
        }

        return name;
    }

    public ArrayList<String> translateIntervalTypes(ArrayList<Character> intervalTypes, ArrayList<Integer> intervalNumbers)
    {
        ArrayList <String> types = new ArrayList<String>();

        if(intervalTypes.contains('v'))
        {
            if(intervalNumbers.contains((Object)0) || intervalNumbers.contains((Object)3) || intervalNumbers.contains((Object)4) || intervalNumbers.contains((Object)7))
            {
                types.add("Čistá");
            }
            if(intervalNumbers.contains((Object)1) || intervalNumbers.contains((Object)2) || intervalNumbers.contains((Object)5) || intervalNumbers.contains((Object)6)){
                types.add("Velká");
            }
        }
        if(intervalTypes.contains('m'))
        {
            if(intervalNumbers.contains((Object)0) || intervalNumbers.contains((Object)3) || intervalNumbers.contains((Object)4) || intervalNumbers.contains((Object)7))
            {
                if(!types.contains("Čistá")) {
                    types.add("Čistá");
                }
            }
            if(intervalNumbers.contains((Object)1) || intervalNumbers.contains((Object)2) || intervalNumbers.contains((Object)5) || intervalNumbers.contains((Object)6)){
                types.add("Malá");
            }
        }
        if(intervalTypes.contains('a'))
        {
            types.add("Zvětšená");
        }
        if(intervalTypes.contains('d'))
        {
            types.add("Zmenšená");
        }

        return types;
    }

    public ArrayList<String> translateAllNumbers(ArrayList<Integer> numbers)
    {
        ArrayList<String> toReturn = new ArrayList<String>();

        for(int number: numbers) {
            toReturn.add(translateIntervalNumber(number));
        }

        return toReturn;
    }

}
